# FreeTV Studio (plugin.video.freetvstudio)

Kodi addon that browses and plays the **publicly exposed** free live-TV index
of [freetv.studio](https://freetv.studio/): live TV, countries, categories,
radio, TV Guide (EPG), favorites, recently played and local search.

The addon only uses data and streams that freetv.studio publishes on its
normal public pages. It does **not** bypass DRM, authentication, paywalls,
geo-restrictions or any other access control, and it hosts no content.

## Features

- **Live TV** — featured/trending channels from the homepage
- **Countries** — 175+ countries with flags and channel counts
- **Categories** — 29 categories (news, sports, movies, music, …)
- **Radio** — audio channels from the site's radio index
- **TV Guide (EPG)** — now/next programs for the curated guide channels
- **Channel details** — description, country, language, now/next program
- **Alternative streams** — full public stream list per channel
- **Search** — local search over the cached channel catalogue
- **Favorites & Recently Played** — stored locally on the device
- **Old-hardware friendly** — stdlib only, timeouts, caching, lazy artwork

## Supported Kodi / Python

- Kodi **Leia (18)** or newer — including Matrix 19+, Nexus 20, Omega 21
- Python **2.7** (Kodi 18) and **3.x** (Kodi 19+) — dual-compatible build
- iOS/tvOS: works with Kodi builds that support `xbmc.python` plugins.
  HLS playback may need **InputStream Adaptive** (see below).

## Installation

1. Download `plugin.video.freetvstudio-x.x.x.zip`.
2. In Kodi: **Add-ons → Install from zip file** → select the zip.
3. Open the addon from **Video add-ons → FreeTV Studio**.

Streaming adapters (recommended):

- `inputstream.adaptive` — best HLS support, required for DASH.
- `inputstream.ffmpegdirect` — alternative HLS handling for old devices.

## Configuration

Open **Settings** inside the addon:

| Setting | Meaning |
|---|---|
| Stream mode | `auto` picks InputStream Adaptive when installed, otherwise the built-in player |
| Max resolution | Cap variants for old devices (default 720) |
| Include DASH | Also offer `.mpd` streams (needs Adaptive) |
| Verify stream | Probe the m3u8 before handing to the player (slower but safer) |
| Timeout / cache TTLs | Network timeout and cache lifetimes |

## How it works

freetv.studio is a Next.js site; all its public data (channels, stream URLs,
EPG) is embedded in React Server Component payloads inside each page's HTML.
The addon fetches the normal public pages and parses those payloads:

- `/countries`, `/categories`, `/country/{CC}`, `/category/{slug}`, `/radio`
- `/guide` for now/next EPG
- `/embed/{id}` and `/channel/{id}` for per-channel stream lists and EPG

Playback passes the public HLS URL straight to Kodi's player (with
InputStream Adaptive when available). The addon never downloads streams.

## Caching

- Channel lists: 24 h · EPG: 30 min · Stream lists: 2 h
- Favorites / recently played: stored permanently (small JSON files)
- Clear from the main menu (**Clear Cache**)

## Known limitations

- The site's own search is client-side only; the addon searches the locally
  cached catalogue instead.
- The TV Guide only covers the site's curated guide channels (~17), not all
  10,000+ channels.
- Some public streams are plain HTTP, dead, geo-blocked or DRM-protected;
  those simply fail to play (the addon reports it instead of crashing).
- Premium Free channels (Pluto TV / Tubi) are external provider links, not
  direct streams, and are not included in Live TV.

## Development

```bash
# inspect the site and save research artifacts
python tools/site_inspector.py

# discover streams for a list of channels
python tools/discover_streams.py --channels BBCNews.uk,DW.de

# test a single stream URL
python tools/test_stream.py --url "https://.../master.m3u8"

# run the unit test suite
python -m pytest tests -v

# live-site smoke test (a handful of requests)
python tools/test_site.py

# rebuild the release zip
python tools/build_zip.py
```

## Troubleshooting

- **Nothing lists** — the site may be unreachable; check Settings → timeout.
- **Channel won't play** — open **Alternative streams** and try another
  public source; many are transient or geo-blocked.
- **Audio but no video** (or vice versa) — try `ffmpegdirect` stream mode.
- **Stutters on old iPad** — lower the max resolution and prefer the
  `native` or `ffmpegdirect` mode; ensure no background apps are running.

## License

MIT — see `LICENSE`. This addon is not affiliated with freetv.studio.
