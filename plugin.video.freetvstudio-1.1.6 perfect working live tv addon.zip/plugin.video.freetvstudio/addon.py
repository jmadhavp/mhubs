#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""FreeTV Studio — Kodi addon entry point.

Usage (inside Kodi)::

    plugin://plugin.video.freetvstudio/?action=main
"""

from __future__ import absolute_import, unicode_literals

import sys

sys.path.append(__import__("os").path.join(
    __import__("os").path.dirname(__file__), "resources", "lib"))

from resources.lib import compat  # noqa: E402
from resources.lib import kodi  # noqa: E402
from resources.lib import router  # noqa: E402


def _parse_params(argv):
    params = {}
    if len(argv) > 2:
        try:
            params = dict(compat.parse_qsl(argv[2][1:]))
        except Exception:  # noqa: BLE001
            params = {}
    return params


def main():
    if not kodi.IN_KODI:
        print("FreeTV Studio addon must run inside Kodi.")
        return
    addon = kodi.xbmcaddon.Addon()
    handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    path = sys.argv[0] if sys.argv else ""
    params = _parse_params(sys.argv)
    r = router.Router(
        addon=addon,
        params=params,
        handle=handle,
        path=path,
        addon_path=kodi.translate_path(addon.getAddonInfo("path")),
    )
    r.dispatch()


if __name__ == "__main__":
    main()
