# -*- coding: utf-8 -*-
"""Read addon settings with defaults (Kodi-free, values injected by router)."""

from __future__ import absolute_import, unicode_literals

from . import compat

DEFAULTS = {
    "max_height": 720,          # 0 = no limit
    "stream_mode": "auto",      # auto | adaptive | ffmpegdirect | native
    "include_dash": False,
    "verify_stream": False,
    "timeout": 15,
    "ttl_channels_hours": 24,
    "ttl_epg_minutes": 30,
    "ttl_streams_hours": 2,
}


def _to_int(value, default):
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return default


def _to_bool(value, default):
    if isinstance(value, bool):
        return value
    if compat.is_text(value):
        return value.lower() in ("true", "1", "yes", "on")
    return default


class Settings(object):
    """Settings facade. Instantiated with a callable ``get(key)->str``."""

    def __init__(self, getter):
        self._get = getter or (lambda key: None)

    def _raw(self, key):
        val = self._get(key)
        return val if val is not None else DEFAULTS.get(key)

    @property
    def max_height(self):
        return _to_int(self._raw("max_height"), 720)

    @property
    def stream_mode(self):
        mode = str(self._raw("stream_mode") or "auto").lower()
        if mode not in ("auto", "adaptive", "ffmpegdirect", "native"):
            return "auto"
        return mode

    @property
    def include_dash(self):
        return _to_bool(self._raw("include_dash"), False)

    @property
    def verify_stream(self):
        return _to_bool(self._raw("verify_stream"), False)

    @property
    def timeout(self):
        return _to_int(self._raw("timeout"), 15)

    @property
    def ttl_channels(self):
        return _to_int(self._raw("ttl_channels_hours"), 24) * 3600

    @property
    def ttl_epg(self):
        return _to_int(self._raw("ttl_epg_minutes"), 30) * 60

    @property
    def ttl_streams(self):
        return _to_int(self._raw("ttl_streams_hours"), 2) * 3600
