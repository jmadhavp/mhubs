# -*- coding: utf-8 -*-
"""High-level scraper: fetch freetv.studio pages and return parsed data.

Combines api.HttpClient with the RSC parser and the Cache. All methods are
cached with sensible TTLs.

No Kodi imports — testable on desktop Python.
"""

from __future__ import absolute_import, unicode_literals

import time

from . import api
from . import parser
from . import rsc
from .__init__ import BASE_URL


class Scraper(object):
    def __init__(self, cache=None, timeout=15, include_dash=False):
        self.http = api.HttpClient(timeout=timeout)
        self.cache = cache
        self.include_dash = include_dash

    # -- low level ---------------------------------------------------------

    def _fetch_text(self, path, cache_key=None, ttl=0, headers=None):
        url = BASE_URL + path
        if cache_key and self.cache and ttl > 0:
            cached = self.cache.get(cache_key)
            if cached is not None:
                return cached
        text = self.http.get_text(url, headers=headers)
        if cache_key and self.cache and ttl > 0:
            self.cache.set(cache_key, text, ttl)
        return text

    def _parse(self, path, parser_fn, cache_key=None, ttl=0):
        text = self._fetch_text(path, cache_key=cache_key, ttl=ttl)
        if not rsc.has_rsc(text):
            raise api.SiteError("Page did not include expected data: " + path)
        return parser_fn(text)

    # -- sections ----------------------------------------------------------

    def get_countries(self, ttl=12 * 3600):
        """List of {code, name, flag, channel_count}."""
        return self._parse("/countries", parser.parse_countries,
                           cache_key="countries", ttl=ttl)

    def get_categories(self, ttl=12 * 3600):
        """List of {slug, name, channel_count}."""
        return self._parse("/categories", parser.parse_categories,
                           cache_key="categories", ttl=ttl)

    def get_country_channels(self, code, category=None, ttl=24 * 3600):
        """Channel cards for a country, optionally filtered by category slug."""
        path = "/country/%s" % code.upper()
        if category:
            path += "?cat=%s" % category
        return self._parse(path, parser.parse_channel_cards,
                           cache_key="country_%s_%s" % (code.lower(), category or "all"),
                           ttl=ttl)

    def get_category_channels(self, slug, ttl=24 * 3600):
        """Channel cards for a category."""
        return self._parse("/category/%s" % slug, parser.parse_channel_cards,
                           cache_key="category_%s" % slug, ttl=ttl)

    def get_homepage_channels(self, ttl=12 * 3600):
        """Channel cards from the homepage (featured/trending sections)."""
        return self._parse("/", parser.parse_channel_cards,
                           cache_key="homepage", ttl=ttl)

    def get_radio_channels(self, ttl=24 * 3600):
        """Channel cards from the /radio page."""
        return self._parse("/radio", parser.parse_channel_cards,
                           cache_key="radio", ttl=ttl)

    def get_embed_streams(self, channel_id, ttl=2 * 3600):
        """Full stream URL list for a channel (from /embed/<id>)."""
        data = self._parse("/embed/%s" % channel_id, parser.parse_embed_streams,
                           cache_key="streams_%s" % channel_id, ttl=ttl)
        if data is None:
            raise api.SiteError("No stream data for channel %s" % channel_id)
        return data

    def get_channel_detail(self, channel_id, ttl=6 * 3600):
        """Detailed channel info incl. now/next EPG programs."""
        return self._parse("/channel/%s" % channel_id, parser.parse_channel_detail,
                           cache_key="channel_%s" % channel_id, ttl=ttl)

    def get_guide(self, ttl=30 * 60):
        """Now/next EPG for the curated guide channels."""
        return self._parse("/guide", parser.parse_guide,
                           cache_key="guide", ttl=ttl)

    # -- stream resolution -------------------------------------------------

    def resolve_streams(self, channel):
        """Return an ordered list of candidate stream URLs for a channel.

        Order: the primary stream (from the card) first, then the full list
        from the embed page. DASH entries are dropped unless include_dash.
        """
        primary = (channel or {}).get("stream_url")
        candidates = []
        if primary:
            candidates.append(primary)
        cid = (channel or {}).get("id")
        if cid:
            try:
                emb = self.get_embed_streams(cid)
            except api.SiteError:
                emb = None
            if emb:
                for url in emb.get("stream_urls") or []:
                    if url not in candidates:
                        candidates.append(url)
        if not self.include_dash:
            candidates = [u for u in candidates if not u.lower().endswith(".mpd")]
        return candidates
