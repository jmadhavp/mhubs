# -*- coding: utf-8 -*-
"""Python 2.7 / Python 3 compatibility shim.

The addon targets both Kodi 18 (Leia, Python 2.7) and Kodi 19+ (Python 3).
This module hides the stdlib differences behind small functions. Everything
here is exercised on Python 3 by tests/test_compat.py; the Python 2 branches
follow the standard py2 idioms and are NOT exercised by the test suite.
"""

from __future__ import absolute_import, unicode_literals

import os
import sys

PY2 = sys.version_info[0] == 2

if PY2:  # pragma: no cover - Python 2 only runs inside Kodi 18
    import urllib as _urllib
    import urllib2 as _urllib2
    import urlparse as _urlparse

    HTTPError = _urllib2.HTTPError
    URLError = _urllib2.URLError
    text_type = unicode  # noqa: F821
else:
    import urllib.error as _urllib_error
    import urllib.parse as _urlparse
    import urllib.request as _urllib2

    HTTPError = _urllib_error.HTTPError
    URLError = _urllib_error.URLError
    text_type = str


def Request(url, headers=None):
    """Build a urllib Request object for both Pythons."""
    return _urllib2.Request(url, headers=headers or {})


def urlopen(req, timeout=None):
    """urllib2/urllib.request.urlopen with an optional timeout."""
    if timeout is None:
        return _urllib2.urlopen(req)
    return _urllib2.urlopen(req, timeout=timeout)


def response_status(resp):
    """HTTP status of a response (``.status`` on py3, ``.code`` on py2)."""
    try:
        return resp.status
    except AttributeError:
        return getattr(resp, "code", None)


def response_headers(resp):
    """Response headers as a plain dict."""
    try:
        return dict(resp.headers)
    except (AttributeError, TypeError):
        return {}


def parse_qsl(query):
    """Parse a query string into [(key, value), ...]."""
    return _urlparse.parse_qsl(query)


def urlencode(params):
    """URL-encode a params dict."""
    if PY2:  # pragma: no cover - Python 2 only runs inside Kodi 18
        def _to_bytes(v):
            if isinstance(v, text_type):
                return v.encode("utf-8")
            return v
        return _urllib.urlencode([(_to_bytes(k), _to_bytes(v))
                                  for k, v in params.items()])
    return _urlparse.urlencode(params)


def urljoin(base, path):
    """Join a URL path onto a base URL."""
    return _urlparse.urljoin(base, path)


def gunzip(data):
    """Decompress gzip bytes (``gzip.decompress`` is py3-only)."""
    import gzip
    try:
        return gzip.decompress(data)
    except AttributeError:  # pragma: no cover - Python 2
        import io as _io
        return gzip.GzipFile(fileobj=_io.BytesIO(data)).read()


def makedirs(path):
    """os.makedirs without the py3-only ``exist_ok`` parameter."""
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except OSError:
            pass


def replace_file(src, dst):
    """Atomically replace dst with src (``os.replace`` is py3-only)."""
    try:
        os.replace(src, dst)
    except AttributeError:  # pragma: no cover - Python 2
        try:
            os.rename(src, dst)
        except OSError:
            try:
                os.remove(dst)
                os.rename(src, dst)
            except OSError:
                pass


def is_text(value):
    """True for str/unicode (py2) and str (py3)."""
    return isinstance(value, text_type) or isinstance(value, str)
