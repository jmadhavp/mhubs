# -*- coding: utf-8 -*-
"""Next.js RSC (React Server Component) payload extraction.

freetv.studio is a Next.js App Router site. All data lives in RSC payloads
embedded in each page's HTML as ``self.__next_f.push([1,"..."])`` calls.
This module extracts and decodes those payloads into plain text that the
parser module can work with.

No Kodi imports here so it can be unit tested on a desktop Python.
"""

from __future__ import absolute_import, unicode_literals

import json
import re

RSC_RE = re.compile(r'self\.__next_f\.push\(\[1,"(.*?)"\]\)</script>', re.S)

# RSC entries are separated by a newline followed by a hex entry id (e.g.
# ``1:``, ``18:``, ``2f:``).
_ENTRY_SPLIT = re.compile(r"\n(?=[0-9a-f]+:)")


def unescape_chunk(chunk):
    """Decode one ``self.__next_f.push`` string body into plain text.

    The chunk is a JS string literal body (escaped with ``\\n``, ``\\"``,
    ``\\uXXXX`` etc). Using JSON string unescaping handles all of those
    correctly while preserving already-decoded UTF-8 characters.
    """
    try:
        return json.loads('"' + chunk + '"')
    except (ValueError, UnicodeDecodeError):
        # Robust fallback: decode common escapes manually. "surrogatepass"
        # is Python 3 only; on Python 2 fall back to the raw chunk.
        try:
            return chunk.encode("utf-8", "surrogatepass").decode(
                "unicode_escape", errors="replace")
        except (LookupError, UnicodeError):
            return chunk


def extract_chunks(html):
    """Return a list of decoded RSC chunks from page HTML."""
    return [unescape_chunk(m.group(1)) for m in RSC_RE.finditer(html)]


def has_rsc(html):
    return RSC_RE.search(html) is not None


def join_chunks(html):
    """Decode every RSC chunk and concatenate them.

    RSC entries are separated by ``\\n`` *inside* the chunk data; chunk
    boundaries themselves can fall in the middle of an entry. Concatenating
    the decoded fragments (with no extra separator) preserves the real entry
    boundaries.
    """
    return "".join(extract_chunks(html))


def split_lines(text):
    """Split decoded RSC text into logical entry lines.

    RSC entries are separated by a newline followed by a hex entry id (e.g.
    ``1:``, ``18:``, ``2f:``). A newline inside a string value must not split
    the entry, hence the lookahead.
    """
    return [line for line in _ENTRY_SPLIT.split(text) if line.strip()]
