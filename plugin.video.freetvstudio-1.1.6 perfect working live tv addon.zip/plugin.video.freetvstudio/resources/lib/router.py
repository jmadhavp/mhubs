# -*- coding: utf-8 -*-
"""FreeTV Studio addon router.

Turns plugin:// URL params into Kodi UI actions. All heavy lifting is done by
the pure modules; this file only orchestrates and renders lists / playback.
"""

from __future__ import absolute_import, unicode_literals

import os
import traceback

from . import api
from . import cache as cache_mod
from . import catalog as catalog_mod
from . import epg as epg_mod
from . import kodi
from . import kodi_ui
from . import metadata
from . import scraper as scraper_mod
from . import settings as settings_mod
from . import streams as streams_mod
from .__init__ import ADDON_ID

LOG_NAME = "[FreeTVStudio]"


def log(message, level=None):
    if not kodi.IN_KODI:
        return
    try:
        kodi.xbmc.log("%s %s" % (LOG_NAME, message),
                      level or kodi.xbmc.LOGINFO)
    except Exception:  # noqa: BLE001
        pass


class Router(object):
    def __init__(self, addon=None, params=None, handle=None, path=None,
                 profile_dir=None, addon_path=None, settings=None,
                 cache=None, catalog=None, http_timeout=None, scraper=None):
        self.addon = addon
        self.params = params or {}
        self.handle = int(handle) if handle is not None else -1
        self.path = path or ""
        self._addon_path = addon_path
        self.settings = settings or settings_mod.Settings(
            self._setting_getter)
        self._cache = cache
        self._catalog = catalog
        self._scraper = scraper
        self._http_timeout = http_timeout

    # ------------------------------------------------------------------
    # bootstrap helpers
    # ------------------------------------------------------------------

    def _setting_getter(self, key):
        if not self.addon:
            return None
        try:
            return kodi_ui.get_setting(self.addon, key, "")
        except Exception:  # noqa: BLE001
            return None

    @property
    def cache_dir(self):
        if self._cache is not None:
            return None
        return self._profile_dir()

    def _profile_dir(self):
        if self.addon:
            try:
                return kodi.translate_path(
                    self.addon.getAddonInfo("profile"))
            except Exception:  # noqa: BLE001
                pass
        return os.path.join(os.path.dirname(__file__), "..", "..",
                            "profile_test")

    @property
    def cache(self):
        if self._cache is None:
            self._cache = cache_mod.Cache(self._profile_dir())
        return self._cache

    @property
    def catalog(self):
        if self._catalog is None:
            self._catalog = catalog_mod.Catalog(self._profile_dir())
        return self._catalog

    @property
    def scraper(self):
        if self._scraper is not None:
            return self._scraper
        return scraper_mod.Scraper(
            cache=self.cache,
            timeout=self.settings.timeout or 15,
            include_dash=self.settings.include_dash,
        )

    @property
    def fanart(self):
        if self._addon_path:
            return os.path.join(self._addon_path, "resources", "images",
                                "fanart.jpg")
        return ""

    # ------------------------------------------------------------------
    # dispatch
    # ------------------------------------------------------------------

    def dispatch(self):
        action = self.params.get("action", "main")
        try:
            handler = getattr(self, "action_%s" % action)
        except AttributeError:
            log("unknown action: %s" % action, kodi.xbmc.LOGWARNING)
            self.action_main()
            return
        try:
            handler()
        except api.SiteError as e:
            log("site error in %s: %s" % (action, e), kodi.xbmc.LOGERROR)
            self._error("Site error: %s" % e)
        except streams_mod.StreamError as e:
            log("stream error in %s: %s" % (action, e), kodi.xbmc.LOGERROR)
            self._error(str(e))
        except Exception as e:  # noqa: BLE001
            log("unhandled error in %s:\n%s" % (action, traceback.format_exc()),
                kodi.xbmc.LOGERROR)
            self._error("Something went wrong (%s: %s) — see kodi.log" % (
                action, type(e).__name__))

    def _error(self, message):
        log(message, kodi.xbmc.LOGERROR)
        kodi_ui.notify("FreeTV Studio", message)
        kodi_ui.end_directory(self.handle, succeeded=False, content=None)

    # ------------------------------------------------------------------
    # actions
    # ------------------------------------------------------------------

    def action_main(self):
        log("opening main menu")
        items = [
            ("Live TV", "live", True),
            ("Countries", "countries", True),
            ("Categories", "categories", True),
            ("Radio", "radio", True),
            ("TV Guide (EPG)", "guide", True),
            ("Sports", "category", True, {"slug": "sports"}),
            ("Search", "search", True),
            ("Favorites", "favorites", True),
            ("Recently Played", "recent", True),
            ("Clear Cache", "clear_cache", False),
            ("About", "about", True),
        ]
        rows = []
        for row in items:
            name, action, folder = row[0], row[1], row[2]
            extra = row[3:]
            params = {"action": action}
            if extra:
                params.update(extra[0])
            li = kodi.xbmcgui.ListItem(label=name)
            if action in ("about",):
                li.setInfo("video", {"plot": _about_text()})
            rows.append((kodi_ui.build_url(params), li, folder))
        kodi_ui.add_directory_items(self.handle, rows)
        kodi_ui.end_directory(self.handle, content="videos")

    def action_live(self):
        log("loading featured channels")
        cards = self.scraper.get_homepage_channels(ttl=12 * 3600)
        self._render_channels(cards, "Featured / Trending")

    def action_countries(self):
        log("loading countries")
        countries = self.scraper.get_countries()
        rows = []
        for c in countries:
            label = "%s (%d)" % (c["name"], c["channel_count"])
            li = kodi.xbmcgui.ListItem(label=label)
            li.setArt({"thumb": c["flag"], "icon": c["flag"]})
            url = kodi_ui.build_url({"action": "country", "code": c["code"]})
            rows.append((url, li, True))
        kodi_ui.add_directory_items(self.handle, rows)
        kodi_ui.end_directory(self.handle, content="videos")

    def action_country(self):
        code = self.params.get("code", "")
        if not code:
            self._error("Missing country code")
            return
        log("loading country %s" % code)
        cards = self.scraper.get_country_channels(code)
        self._render_channels(cards, "Country %s" % code.upper())

    def action_categories(self):
        log("loading categories")
        cats = self.scraper.get_categories()
        rows = []
        for c in cats:
            label = "%s (%d)" % (c["name"], c["channel_count"])
            li = kodi.xbmcgui.ListItem(label=label)
            url = kodi_ui.build_url({"action": "category",
                                     "slug": c["slug"]})
            rows.append((url, li, True))
        kodi_ui.add_directory_items(self.handle, rows)
        kodi_ui.end_directory(self.handle, content="videos")

    def action_category(self):
        slug = self.params.get("slug", "")
        if not slug:
            self._error("Missing category")
            return
        log("loading category %s" % slug)
        cards = self.scraper.get_category_channels(slug)
        self._render_channels(cards, "Category %s" % slug)

    def action_radio(self):
        log("loading radio channels")
        try:
            cards = self.scraper.get_radio_channels()
        except api.SiteError:
            cards = []
        if not cards:
            self._error("Radio list unavailable")
            return
        self._render_channels(cards, "Radio")

    def action_guide(self):
        log("loading tv guide")
        try:
            guide = self.scraper.get_guide(ttl=self.settings.ttl_epg)
        except api.SiteError as e:
            self._error("Guide unavailable: %s" % e)
            return
        programs = epg_mod.programs_from_guide(guide)
        by_id = {c["id"]: c for c in guide.get("channels") or []}
        rows = []
        for p in programs:
            ch = by_id.get(p["channel_id"])
            if not ch:
                continue
            label = "%s: %s" % (ch.get("name"), p.title)
            li = kodi_ui.make_listitem(ch, playable=True, fanart=self.fanart)
            li.setLabel(label)
            if p.end:
                li.setInfo("video", {"plot": "%s\nUntil %s" % (
                    p.title, metadata.format_time_iso(p.end))})
            url = kodi_ui.build_url({"action": "play", "id": ch["id"]})
            rows.append((url, li, False))
        if not rows:
            self._error("No guide data")
            return
        kodi_ui.add_directory_items(self.handle, rows)
        kodi_ui.end_directory(self.handle, content="videos")

    def action_channel(self):
        cid = self.params.get("id", "")
        if not cid:
            self._error("Missing channel id")
            return
        log("channel detail: %s" % cid)
        try:
            detail = self.scraper.get_channel_detail(cid)
        except api.SiteError:
            detail = None
        if not detail or not detail.get("stream_urls"):
            self._error("Channel not found: %s" % cid)
            return
        programs = epg_mod.programs_from_channel_detail(detail)
        now, nxt = epg_mod.now_and_next(programs, cid)
        label = detail.get("name") or cid
        li = kodi_ui.make_listitem(detail, playable=True, fanart=self.fanart)
        plot = []
        if detail.get("country_name"):
            plot.append("Country: %s" % detail["country_name"])
        if detail.get("language"):
            plot.append("Language: %s" % detail["language"])
        if detail.get("description"):
            plot.append(detail["description"])
        if now:
            plot.append("Now: %s" % now.title)
        if nxt:
            plot.append("Next: %s (%s)" % (nxt.title,
                                            metadata.format_time_iso(nxt.start)))
        li.setInfo("video", {"plot": "\n".join(plot)})
        rows = [
            (kodi_ui.build_url({"action": "play", "id": cid}),
             li, False),
        ]
        # alternative streams sub-menu
        streams_li = kodi.xbmcgui.ListItem(label="Alternative streams (%d)" %
                                           len(detail["stream_urls"]))
        rows.append((kodi_ui.build_url({"action": "streams", "id": cid}),
                     streams_li, True))
        kodi_ui.add_directory_items(self.handle, rows)
        kodi_ui.end_directory(self.handle, content="videos")

    def action_streams(self):
        cid = self.params.get("id", "")
        if not cid:
            self._error("Missing channel id")
            return
        try:
            data = self.scraper.get_embed_streams(cid)
        except api.SiteError as e:
            self._error("No streams: %s" % e)
            return
        urls = data.get("stream_urls") or []
        if not self.settings.include_dash:
            urls = [u for u in urls if not u.lower().endswith(".mpd")]
        rows = []
        for i, url in enumerate(urls, 1):
            kind = "DASH" if url.lower().endswith(".mpd") else "HLS"
            secure = "https" if url.startswith("https") else "http"
            li = kodi.xbmcgui.ListItem(label="Stream %d [%s/%s]" %
                                       (i, kind, secure))
            li.setProperty("IsPlayable", "true")
            rows.append((kodi_ui.build_url({"action": "play_stream",
                                            "url": url}), li, False))
        kodi_ui.add_directory_items(self.handle, rows)
        kodi_ui.end_directory(self.handle, content="videos")

    # ------------------------------------------------------------------
    # search / favorites / recent
    # ------------------------------------------------------------------

    def action_search(self):
        kb = kodi.xbmc.Keyboard("", "Search FreeTV Studio", False)
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            query = kb.getText().strip()
            if query:
                self._run_search(query)
                return
        kodi_ui.end_directory(self.handle, content="videos")

    def _run_search(self, query):
        log("search: %s" % query)
        results = self._local_search(query)
        self._render_channels(results, "Results for '%s' (%d)" % (query,
                                                                  len(results)))

    def _local_search(self, query):
        listings = []
        for key in self.cache.list_keys():
            if key.startswith("country_") or key.startswith("category_") or \
                    key in ("homepage", "radio"):
                listings.extend(self.cache.get(key) or [])
        if not listings:
            # seed with a few common category pages so first search isn't empty
            for slug in ("news", "general", "sports", "music", "movies"):
                try:
                    listings.extend(self.scraper.get_category_channels(slug))
                except api.SiteError:
                    continue
        return self.catalog.search(listings, query, limit=200)

    def action_favorites(self):
        favs = self.catalog.get_favorites()
        if not favs:
            self._error("No favorites yet")
            return
        self._render_channels(favs, "Favorites")

    def action_recent(self):
        recents = self.catalog.get_recent()
        if not recents:
            self._error("Nothing played yet")
            return
        self._render_channels(recents, "Recently Played")

    def action_add_fav(self):
        cid = self.params.get("id", "")
        ch = self._channel_from_cache(cid)
        if not ch:
            self._error("Cannot find channel %s" % cid)
            return
        self.catalog.add_favorite(ch)
        kodi_ui.notify("FreeTV Studio", "Added to favorites")
        kodi.xbmc.executebuiltin("Container.Refresh")

    def action_remove_fav(self):
        cid = self.params.get("id", "")
        self.catalog.remove_favorite(cid)
        kodi_ui.notify("FreeTV Studio", "Removed from favorites")
        kodi.xbmc.executebuiltin("Container.Refresh")

    def action_clear_cache(self):
        self.cache.clear()
        kodi_ui.notify("FreeTV Studio", "Cache cleared")
        kodi_ui.end_directory(self.handle, content="videos")

    def action_about(self):
        li = kodi.xbmcgui.ListItem(label="About")
        li.setInfo("video", {"plot": _about_text()})
        kodi_ui.add_directory_items(self.handle,
                                    [(kodi_ui.build_url({"action": "main"}),
                                      li, False)])
        kodi_ui.end_directory(self.handle, content="videos")

    # ------------------------------------------------------------------
    # playback
    # ------------------------------------------------------------------

    def action_play(self):
        cid = self.params.get("id", "")
        ch = self._channel_from_cache(cid) or {"id": cid}
        if not cid:
            self._error("Missing channel id")
            return
        self._play_channel(ch)

    def action_play_stream(self):
        url = self.params.get("url", "")
        if not url:
            self._error("Missing stream url")
            return
        self._start_playback(url, "direct")

    def _play_channel(self, channel):
        cid = channel.get("id")
        log("resolving channel: %s" % cid)
        try:
            candidates = self.scraper.resolve_streams(channel)
        except api.SiteError as e:
            self._error("Cannot resolve streams: %s" % e)
            return
        if not candidates:
            self._error("No streams available for %s" % (channel.get("name") or cid))
            return
        chosen = candidates[0]
        note = "primary"
        if self.settings.verify_stream:
            probe = streams_mod.probe_stream(
                chosen, timeout=self.settings.timeout,
                referer="https://freetv.studio/channel/%s" % cid)
            if probe.get("error"):
                log("primary stream failed (%s); trying alternatives"
                    % probe["error"])
                for alt in candidates[1:]:
                    p2 = streams_mod.probe_stream(
                        alt, timeout=self.settings.timeout,
                        referer="https://freetv.studio/channel/%s" % cid)
                    if not p2.get("error"):
                        chosen = alt
                        note = "alternative"
                        break
                else:
                    self._error("All streams failed")
                    return
        self._start_playback(chosen, note)
        if cid:
            self.catalog.add_recent(self._channel_from_cache(cid) or channel)

    def _start_playback(self, url, note):
        log("playback URL resolved (%s): %s" % (note, url))
        mode = self.settings.stream_mode
        item = kodi.xbmcgui.ListItem(path=url)
        item.setProperty("IsPlayable", "true")
        item.setInfo("video", {"title": self.params.get("id", "FreeTV")})

        is_dash = url.lower().endswith(".mpd")
        if is_dash and not self.settings.include_dash:
            self._error("DASH stream requires InputStream Adaptive")
            return

        if mode == "native":
            pass
        elif mode == "adaptive":
            self._configure_inputstream(item, "inputstream.adaptive",
                                        "mpd" if is_dash else "hls")
        elif mode == "ffmpegdirect":
            self._configure_inputstream(item, "inputstream.ffmpegdirect",
                                        "mpd" if is_dash else "hls")
        else:  # auto
            if is_dash:
                self._configure_inputstream(item, "inputstream.adaptive", "mpd")
            elif _has_addon("inputstream.adaptive"):
                self._configure_inputstream(item, "inputstream.adaptive", "hls")
            elif _has_addon("inputstream.ffmpegdirect"):
                self._configure_inputstream(item, "inputstream.ffmpegdirect",
                                            "hls")

        kodi_ui.set_resolved(self.handle, True, item)

    def _configure_inputstream(self, item, addon, manifest_type):
        item.setProperty("inputstreamaddon", addon)
        item.setProperty("inputstream.%s.manifest_type" % addon.split(".")[-1],
                         manifest_type)
        item.setProperty("inputstream.%s.stream_headers" %
                         addon.split(".")[-1],
                         "User-Agent=Mozilla/5.0 (Kodi)")

    # ------------------------------------------------------------------
    # rendering
    # ------------------------------------------------------------------

    def _render_channels(self, channels, title):
        if not channels:
            self._error("No channels available for %s" % title)
            return
        rows = []
        for ch in channels:
            url = kodi_ui.build_url({"action": "play", "id": ch["id"]})
            li = kodi_ui.make_listitem(ch, playable=True, fanart=self.fanart)
            cid = ch.get("id")
            menu = [
                ("Streams", "XBMC.Container.Update(%s)" %
                 kodi_ui.build_url({"action": "streams", "id": cid})),
                ("Details", "XBMC.Container.Update(%s)" %
                 kodi_ui.build_url({"action": "channel", "id": cid})),
            ]
            if self.catalog.is_favorite(cid):
                menu.append(("Remove from favorites", "XBMC.Container.Update(%s)"
                             % kodi_ui.build_url({"action": "remove_fav",
                                                  "id": cid})))
            else:
                menu.append(("Add to favorites", "XBMC.Container.Update(%s)"
                             % kodi_ui.build_url({"action": "add_fav",
                                                  "id": cid})))
            li.addContextMenuItems(menu)
            rows.append((url, li, False))
        kodi_ui.add_directory_items(self.handle, rows)
        kodi_ui.end_directory(self.handle, content="videos")

    def _channel_from_cache(self, cid):
        """Try to reconstruct a channel dict from cached listings."""
        for key in self.cache.list_keys():
            if key.startswith("country_") or key.startswith("category_") or \
                    key in ("homepage", "radio", "guide"):
                data = self.cache.get(key) or []
                if isinstance(data, dict):
                    data = [data]
                for ch in data:
                    if isinstance(ch, dict) and ch.get("id") == cid:
                        return ch
        return None


def _has_addon(addon_id_name):
    if not kodi.IN_KODI:
        return False
    try:
        return bool(kodi.xbmc.getCondVisibility(
            "System.HasAddon(%s)" % addon_id_name))
    except Exception:  # noqa: BLE001
        return False


def _about_text():
    return ("FreeTV Studio\n"
            "Browses the public channel index of freetv.studio.\n\n"
            "All channels, logos and streams are the site's own publicly "
            "exposed data. Streams are played directly via Kodi's player "
            "with optional InputStream Adaptive for HLS/DASH.\n\n"
            "Optimised for older devices: lightweight requests, lazy "
            "artwork and persistent caching.")
