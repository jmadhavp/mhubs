# -*- coding: utf-8 -*-
"""HLS / stream analysis and selection.

Probes stream URLs, parses M3U8 playlists, and picks the most compatible
variant for old hardware. Pure Python + stdlib.

No Kodi imports — testable on desktop Python.
"""

from __future__ import absolute_import, unicode_literals

import re
import time

from . import api
from . import compat


class StreamError(Exception):
    """Raised when a stream cannot be used for playback."""


# ---------------------------------------------------------------------------
# m3u8 parsing
# ---------------------------------------------------------------------------

_EXT_X_STREAM_INF = re.compile(
    r'#EXT-X-STREAM-INF:(?P<attrs>[^\n]*)(?:\n(?P<uri>[^\n]+))')


def _parse_attrs(attrs):
    out = {}
    for part in attrs.split(","):
        if "=" in part:
            key, _, val = part.partition("=")
            out[key.strip()] = val.strip().strip('"')
    return out


def parse_m3u8(text):
    """Parse an M3U8 playlist.

    Returns dict with keys:
      is_master: bool
      variants: [{"bandwidth": int, "resolution": "1280x720"|None,
                  "codecs": str|None, "uri": str}]
      segments: int (count of EXTINF segments)
      target_duration: int or None
      error: None or str
    """
    result = {
        "is_master": False,
        "variants": [],
        "segments": 0,
        "target_duration": None,
        "error": None,
    }
    text = text or ""
    if "#EXTM3U" not in text:
        result["error"] = "not an m3u8 playlist"
        return result
    result["target_duration"] = _first_int(text, r"#EXT-X-TARGETDURATION:(\d+)")
    result["is_master"] = "#EXT-X-STREAM-INF:" in text
    result["segments"] = len(re.findall(r"#EXTINF:", text))
    if result["is_master"]:
        for m in _EXT_X_STREAM_INF.finditer(text):
            attrs = _parse_attrs(m.group("attrs"))
            uri = (m.group("uri") or "").strip()
            if not uri:
                continue
            bandwidth = _safe_int(attrs.get("BANDWIDTH"))
            result["variants"].append({
                "bandwidth": bandwidth,
                "resolution": attrs.get("RESOLUTION"),
                "codecs": attrs.get("CODECS"),
                "uri": uri,
            })
        result["variants"].sort(key=lambda v: v["bandwidth"] or 0)
    return result


def _first_int(text, pattern):
    m = re.search(pattern, text)
    return int(m.group(1)) if m else None


def _safe_int(value):
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return 0


def variant_height(variant):
    res = variant.get("resolution")
    if res and "x" in res:
        try:
            return int(res.split("x")[1])
        except (ValueError, IndexError):
            return 0
    return 0


def is_h264_or_unknown(codecs):
    """Prefer H.264/AAC (the safe combo for old iPads)."""
    if not codecs:
        return True
    low = codecs.lower()
    if "avc1" in low or "avc3" in low or "mp4a" in low:
        return True
    return False


def best_variant(variants, max_height=720):
    """Pick the highest-bandwidth variant whose height <= max_height.

    Ties go to H.264/unknown codecs over HEVC/AV1. Returns None when no
    variant qualifies.
    """
    if not variants:
        return None
    usable = []
    for v in variants:
        h = variant_height(v)
        if max_height and h > max_height:
            continue
        if not v.get("uri"):
            continue
        usable.append(v)
    if not usable:
        usable = [v for v in variants if v.get("uri")]
    if not usable:
        return None
    usable.sort(key=lambda v: (v["bandwidth"] or 0, is_h264_or_unknown(v.get("codecs"))))
    return usable[-1]


# ---------------------------------------------------------------------------
# probing
# ---------------------------------------------------------------------------

def probe_stream(url, timeout=15, headers=None, referer=None):
    """Probe a stream URL without downloading it fully.

    Returns dict:
      url, status, content_type, redirected_to, is_hls, master,
      media, variants, segments, target_duration, expires_seconds, error
    """
    out = {
        "url": url,
        "status": None,
        "content_type": None,
        "redirected_to": None,
        "is_hls": False,
        "is_master": None,
        "variants": None,
        "segments": None,
        "target_duration": None,
        "error": None,
    }
    http = api.HttpClient(timeout=timeout)
    try:
        status, body, resp_headers = http.get_bytes(url, headers=headers,
                                                    referer=referer)
    except api.SiteError as e:
        out["error"] = str(e)
        return out
    out["status"] = status
    if status is None or status >= 400:
        out["error"] = "HTTP %s" % status
        return out
    if body is None:
        out["error"] = "response too large to probe"
        return out
    out["content_type"] = resp_headers.get("Content-Type", "")
    out["redirected_to"] = resp_headers.get("Content-Location") or (
        resp_headers.get("Location"))
    if len(body) > 512 * 1024:
        out["error"] = "body unexpectedly large; not an hls playlist?"
        return out
    try:
        text = body.decode("utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        out["error"] = "undecodable body"
        return out
    if "#EXTM3U" in text:
        out["is_hls"] = True
        parsed = parse_m3u8(text)
        out["is_master"] = parsed["is_master"]
        out["variants"] = parsed["variants"]
        out["segments"] = parsed["segments"]
        out["target_duration"] = parsed["target_duration"]
        if parsed["error"]:
            out["error"] = parsed["error"]
    else:
        out["error"] = "not an HLS playlist"
    return out


def resolve_media_playlist(master_url, variant_uri, timeout=15):
    """Resolve a variant URI against a master playlist URL.

    Returns (media_url, parsed_media) where parsed_media has segments count
    and target duration. Returns (None, None) on failure.
    """
    media_url = compat.urljoin(master_url, variant_uri)
    try:
        status, body, _ = api.HttpClient(timeout=timeout).get_bytes(media_url)
    except api.SiteError:
        return None, None
    if status is None or status >= 400 or body is None:
        return None, None
    text = body.decode("utf-8", errors="replace")
    if "#EXTM3U" not in text:
        return None, None
    return media_url, parse_m3u8(text)


# ---------------------------------------------------------------------------
# end-to-end resolution for playback
# ---------------------------------------------------------------------------

def resolve_playback(url, timeout=15, max_height=720, headers=None,
                     referer=None):
    """Prepare a URL for Kodi playback.

    If the URL is an HLS master playlist, select the best variant for the
    target device and return the media playlist URL. Otherwise return the URL
    unchanged.

    Returns dict: {"url": str, "note": str, "probe": dict}
    """
    probe = probe_stream(url, timeout=timeout, headers=headers,
                         referer=referer)
    if probe["error"] or not probe["is_hls"]:
        return {"url": url, "note": "direct", "probe": probe}
    if not probe["is_master"]:
        return {"url": url, "note": "hls-media", "probe": probe}
    choice = best_variant(probe["variants"], max_height=max_height)
    if choice is None:
        return {"url": url, "note": "hls-master-fallback", "probe": probe}
    media_url, parsed = resolve_media_playlist(url, choice["uri"],
                                               timeout=timeout)
    if media_url is None:
        return {"url": url, "note": "hls-master-fallback", "probe": probe}
    note = "hls-variant %s (%s kbps)" % (
        choice["resolution"] or "?", (choice["bandwidth"] or 0) // 1000)
    return {"url": media_url, "note": note, "probe": probe}
