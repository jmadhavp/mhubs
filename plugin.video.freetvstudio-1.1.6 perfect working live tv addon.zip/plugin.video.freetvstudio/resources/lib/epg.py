# -*- coding: utf-8 -*-
"""EPG helpers.

The site exposes two forms of public EPG data:
  1. A /guide page with now/next programs for a curated set of channels.
  2. JSON-LD BroadcastEvent blocks on each /channel/<id> page (current +
     next program with start/end timestamps).

This module normalises both into a simple model and provides lookups.

Pure Python, no Kodi imports.
"""

from __future__ import absolute_import, unicode_literals

import re

_ISO_RE = re.compile(
    r"^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(Z|[+-]\d{2}:?\d{2})$")


def parse_iso(iso):
    """Parse an ISO-8601 timestamp into a UTC time_struct or None.

    Returns (year, month, day, hour, minute, second) tuple in UTC.
    """
    m = _ISO_RE.match(iso or "")
    if not m:
        return None
    year, month, day, hour, minute, second = (int(g) for g in m.groups()[:6])
    tz = m.group(7)
    try:
        import calendar
        ts = calendar.timegm((year, month, day, hour, minute, second, 0, 0, 0))
    except (ValueError, OverflowError):
        return None
    if tz not in ("Z", "z"):
        sign = 1 if tz[0] == "+" else -1
        off_h = int(tz[1:3])
        off_m = int(tz[4:6]) if len(tz) > 4 else 0
        ts -= sign * (off_h * 3600 + off_m * 60)
    return ts


def parse_iso_hhmm_ampm(text):
    """Parse '09:20 AM' -> (hour, minute) 24h or None."""
    m = re.match(r"(\d{1,2}):(\d{2})\s*([APap]\.?[Mm]\.?)", text or "")
    if not m:
        return None
    hour = int(m.group(1))
    minute = int(m.group(2))
    ampm = m.group(3).lower()
    if ampm.startswith("p") and hour < 12:
        hour += 12
    if ampm.startswith("a") and hour == 12:
        hour = 0
    return hour, minute


class Program(object):
    __slots__ = ("channel_id", "title", "start", "end", "live", "now")

    def __init__(self, channel_id, title, start=None, end=None, live=False,
                 now=False):
        self.channel_id = channel_id
        self.title = title or ""
        self.start = start       # ISO string (UTC)
        self.end = end           # ISO string (UTC) or None
        self.live = bool(live)
        self.now = bool(now)

    def start_ts(self):
        return parse_iso(self.start)

    def end_ts(self):
        return parse_iso(self.end)

    def as_dict(self):
        return {
            "channel_id": self.channel_id,
            "title": self.title,
            "start": self.start,
            "end": self.end,
            "live": self.live,
            "now": self.now,
        }


def programs_from_guide(guide):
    """Convert a parsed /guide payload into Program objects.

    The guide's per-program ``start`` is UTC from the RSC key; ``end`` is the
    start of the next program on the same channel (already computed by the
    parser).
    """
    by_channel = {}
    for p in guide.get("programs") or []:
        by_channel.setdefault(p["channel_id"], []).append(p)
    programs = []
    for cid, items in by_channel.items():
        items.sort(key=lambda p: p["start"] or "")
        for i, p in enumerate(items):
            programs.append(Program(
                channel_id=cid,
                title=p["title"],
                start=p["start"],
                end=p["end"],
                live=(i == 0),
                now=(i == 0),
            ))
    return programs


def programs_from_channel_detail(detail):
    """Convert JSON-LD BroadcastEvents from a channel page into Programs."""
    programs = []
    for ev in detail.get("programs") or []:
        programs.append(Program(
            channel_id=detail.get("id"),
            title=ev.get("title"),
            start=ev.get("start"),
            end=ev.get("end"),
            live=ev.get("live", False),
        ))
    if programs and programs[0].start_ts():
        programs[0].now = True
    return programs


def now_and_next(programs, channel_id, now_ts=None):
    """Return (now_program, next_program) for a channel at now_ts."""
    if now_ts is None:
        now_ts = _utcnow()
    matches = [p for p in programs if p.channel_id == channel_id]
    if not matches:
        return None, None
    ordered = sorted(matches, key=lambda p: p.start_ts() or 0)
    current = None
    for i, p in enumerate(ordered):
        s = p.start_ts()
        e = p.end_ts()
        if s is None:
            continue
        if s <= now_ts and (e is None or e > now_ts):
            current = p
            return current, ordered[i + 1] if i + 1 < len(ordered) else None
    return None, (ordered[0] if ordered else None)


def _utcnow():
    return int(time.time())


import time  # noqa: E402  (kept at bottom for clarity)
