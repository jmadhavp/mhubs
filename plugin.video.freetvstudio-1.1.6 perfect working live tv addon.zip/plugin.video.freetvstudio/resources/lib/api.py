# -*- coding: utf-8 -*-
"""Lightweight HTTP layer for freetv.studio.

Uses only the standard library. No Kodi imports — testable on desktop Python.
Streams responses lazily when possible; never holds large bodies in RAM
longer than needed.
"""

from __future__ import absolute_import, unicode_literals

import gzip
import io
import zlib

from . import compat
from .__init__ import BASE_URL, USER_AGENT


class SiteError(Exception):
    """Raised for site-level failures (unreachable, HTTP error, timeout)."""

    def __init__(self, message, code=None, url=None):
        super(SiteError, self).__init__(message)
        self.code = code
        self.url = url


def build_headers(extra=None, referer=None):
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Accept-Encoding": "gzip, deflate",
        "Connection": "close",
    }
    if referer:
        headers["Referer"] = referer
    if extra:
        headers.update(extra)
    return headers


class HttpClient(object):
    """Small urllib wrapper with timeouts, gzip and redirect handling."""

    def __init__(self, timeout=15, max_body=8 * 1024 * 1024):
        self.timeout = timeout
        self.max_body = max_body

    # -- public ------------------------------------------------------------

    def get_text(self, url, headers=None, referer=None):
        """GET a page and return its decoded text body."""
        status, body, resp_headers = self.get_bytes(url, headers=headers,
                                                    referer=referer)
        if status is None:
            raise SiteError("Request failed for %s" % url, url=url)
        if status >= 400:
            raise SiteError("HTTP %s for %s" % (status, url), code=status, url=url)
        return body.decode("utf-8", errors="replace")

    def get_bytes(self, url, headers=None, referer=None, range_header=None):
        """GET and return (status, bytes or None, response headers dict)."""
        req_headers = build_headers(extra=headers, referer=referer)
        if range_header:
            req_headers["Range"] = range_header
        req = compat.Request(url, headers=req_headers)
        resp = None
        try:
            resp = compat.urlopen(req, timeout=self.timeout)
            data = resp.read(self.max_body + 1)
            if len(data) > self.max_body:
                return (compat.response_status(resp), None,
                        compat.response_headers(resp))
            enc = resp.headers.get("Content-Encoding", "")
            if enc == "gzip":
                data = compat.gunzip(data)
            elif enc == "deflate":
                data = zlib.decompress(data)
            return (compat.response_status(resp), data,
                    compat.response_headers(resp))
        except compat.HTTPError as e:
            return e.code, None, dict(getattr(e, "headers", {}))
        except compat.URLError as e:
            raise SiteError("Network error for %s: %s" % (url, e.reason),
                            url=url)
        except (OSError, IOError, ValueError) as e:
            raise SiteError("Request error for %s: %s" % (url, e), url=url)
        finally:
            if resp is not None:
                resp.close()

    def open_stream(self, url, headers=None, referer=None, max_bytes=None):
        """Open a response for streaming (used by stream probes).

        Returns (status, file-like object, response headers) or raises
        SiteError. The caller must close the file-like object.
        """
        req_headers = build_headers(extra=headers, referer=referer)
        req = compat.Request(url, headers=req_headers)
        try:
            resp = compat.urlopen(req, timeout=self.timeout)
        except compat.HTTPError as e:
            raise SiteError("HTTP %s for %s" % (e.code, url), code=e.code,
                            url=url)
        except compat.URLError as e:
            raise SiteError("Network error for %s: %s" % (url, e.reason),
                            url=url)
        enc = resp.headers.get("Content-Encoding", "")
        if enc == "gzip":
            return (compat.response_status(resp),
                    gzip.GzipFile(fileobj=resp), compat.response_headers(resp))
        return compat.response_status(resp), resp, compat.response_headers(resp)


def url_join(base, path):
    return compat.urljoin(base, path)


def absolute(url):
    """Make a URL absolute against the site base."""
    if url.startswith("//"):
        return "https:" + url
    if url.startswith("/"):
        return BASE_URL + url
    return url
