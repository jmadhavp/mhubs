# -*- coding: utf-8 -*-
"""FreeTV Studio Kodi addon."""

from __future__ import absolute_import, unicode_literals

__version__ = "1.1.6"
ADDON_ID = "plugin.video.freetvstudio"
BASE_URL = "https://freetv.studio"
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36"
)
