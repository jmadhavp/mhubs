# -*- coding: utf-8 -*-
"""Lazy Kodi API bridge.

Keeps xbmc imports in one place so the rest of the codebase can be unit
tested on desktop Python (where xbmc is absent) by injecting fake modules
into ``sys.modules`` before importing this module.

Usage::

    from resources.lib import kodi
    kodi.xbmcgui.ListItem(...)
"""

from __future__ import absolute_import, unicode_literals

import sys

try:  # pragma: no cover - exercised inside Kodi only
    import xbmc
    import xbmcgui
    import xbmcplugin
    import xbmcaddon
    import xbmcvfs
    IN_KODI = True
except ImportError:  # pragma: no cover - desktop tests
    xbmc = None
    xbmcgui = None
    xbmcplugin = None
    xbmcaddon = None
    xbmcvfs = None
    IN_KODI = False


def require_kodi():
    if not IN_KODI:
        raise RuntimeError("This action requires a Kodi runtime")


def addon_id():
    return "plugin.video.freetvstudio"


def translate_path(path):
    """Resolve a special:// path to a real filesystem path.

    Kodi returns URLs like ``special://profile/addon_data/...`` from
    ``getAddonInfo``; os.* calls need the physical path. ``xbmcvfs`` gained
    ``translatePath`` in Matrix (Kodi 19); Leia (Kodi 18) uses
    ``xbmc.translatePath``.
    """
    if not IN_KODI or not path:
        return path
    try:
        return xbmcvfs.translatePath(path)
    except AttributeError:  # pragma: no cover - Kodi 18 (Leia)
        pass
    try:
        return xbmc.translatePath(path)
    except AttributeError:  # pragma: no cover
        return path
