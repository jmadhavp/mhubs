# -*- coding: utf-8 -*-
"""Parser for freetv.studio Next.js RSC payloads.

The site is server-side rendered (Next.js App Router). Every page embeds its
data in ``self.__next_f.push`` RSC payloads. This module turns decoded RSC
text (see rsc.py) into plain Python data structures.

Pure Python, no Kodi imports — unit testable on desktop Python.
"""

from __future__ import absolute_import, unicode_literals

import json
import re

from . import rsc

# ---------------------------------------------------------------------------
# generic helpers
# ---------------------------------------------------------------------------

_ANY_STR = r'((?:[^"\\]|\\.)*?)'  # matches an escaped JSON string body
_RE_ID = re.compile(r'data-ga-id":"([^"]+)"')
_RE_NAME_LOGO = re.compile(r'"name":"' + _ANY_STR + r'","logoUrl":"' + _ANY_STR + r'"')
_RE_STREAM = re.compile(r'"streamUrl":"' + _ANY_STR + r'"')
_RE_FLAG = re.compile(r'flagcdn\.com/([a-z]{2})\.svg","alt":"' + _ANY_STR + r'"')
_RE_CATEGORY_TAG = re.compile(
    r'\[\"\$\",\"span\",\"([a-z0-9_]+)\",\{[^{}]*?"children":"' + _ANY_STR + r'"')
_RE_COUNT_CHANNELS = re.compile(r'"children":"(\d+)\s+channels?"')


def _unescape_json_str(value):
    try:
        return json.loads('"' + value + '"')
    except (ValueError, UnicodeDecodeError):
        return value


def _first(pattern, text, default=None, group=1):
    m = pattern.search(text)
    if m:
        return m.group(group)
    return default


def _all(pattern, text, group=1):
    return [m.group(group) for m in pattern.finditer(text)]


# ---------------------------------------------------------------------------
# channel cards
# ---------------------------------------------------------------------------

def parse_channel_cards(html_or_rsc):
    """Parse channel cards from a listing page (homepage / country / category).

    Returns a list of dicts::

        {
          "id": "BBCNews.uk",
          "name": "BBC News",
          "logo": "https://...",
          "stream_url": "https://...m3u8",
          "country_code": "uk",
          "country_name": "United Kingdom",
          "categories": [{"slug": "news", "name": "News"}],
          "description": "optional short text or null",
          "live": True,
        }
    """
    text = _to_rsc(html_or_rsc)
    lines = rsc.split_lines(text)
    out = []
    seen = set()
    for line in lines:
        if '"data-ga-content":"channel"' not in line:
            continue
        cid = _first(_RE_ID, line)
        if not cid or cid in seen:
            continue
        seen.add(cid)
        name, logo = None, None
        m = _RE_NAME_LOGO.search(line)
        if m:
            name = _unescape_json_str(m.group(1))
            logo_val = m.group(2)
            logo = None if logo_val in ("$undefined", "undefined") else logo_val
        stream = _first(_RE_STREAM, line)
        if stream == "$undefined":
            stream = None
        cc, cname = None, None
        m = _RE_FLAG.search(line)
        if m:
            cc = m.group(1)
            cname = _unescape_json_str(m.group(2))
        description = _extract_description(line)
        categories = [
            {"slug": s, "name": _unescape_json_str(n)}
            for s, n in _RE_CATEGORY_TAG.findall(line)
        ]
        out.append({
            "id": cid,
            "name": name or cid,
            "logo": logo,
            "stream_url": stream,
            "country_code": cc,
            "country_name": cname,
            "categories": categories,
            "description": description,
            "live": 'title="Online now' in line or 'border-emerald-500/30' in line,
        })
    return out


def _extract_description(line):
    """Description sits between the muted paragraph class and the flag img."""
    start = line.find("truncate text-xs text-muted-foreground")
    end = line.find("flagcdn")
    if start == -1 or end == -1 or end <= start:
        return None
    seg = line[start:end]
    m = re.search(r'"children":"' + _ANY_STR + r'"', seg)
    if not m:
        return None
    value = _unescape_json_str(m.group(1))
    return value or None


# ---------------------------------------------------------------------------
# countries / categories index pages
# ---------------------------------------------------------------------------

def parse_countries(html_or_rsc):
    """Parse the /countries page.

    Returns list of dicts: {"code": "AF", "name": "Afghanistan",
    "flag": "https://flagcdn.com/af.svg", "channel_count": 9}
    """
    text = _to_rsc(html_or_rsc)
    lines = rsc.split_lines(text)
    out = []
    for line in lines:
        if '"data-ga-content":"country"' not in line:
            continue
        m = re.search(r'href":"/country/([A-Z]{2})"', line)
        if not m:
            continue
        code = m.group(1).lower()
        name = _first(_RE_FLAG, line, default=None, group=2)
        count = _first(_RE_COUNT_CHANNELS, line, default=0)
        out.append({
            "code": code,
            "name": _unescape_json_str(name) if name else code.upper(),
            "flag": "https://flagcdn.com/%s.svg" % code,
            "channel_count": int(count) if str(count).isdigit() else 0,
        })
    return out


def parse_categories(html_or_rsc):
    """Parse the /categories page.

    Returns list of dicts: {"slug": "news", "name": "News",
    "channel_count": 740}
    """
    text = _to_rsc(html_or_rsc)
    lines = rsc.split_lines(text)
    out = []
    for line in lines:
        if '"data-ga-content":"category"' not in line:
            continue
        m = re.search(r'href":"/category/([a-z0-9_-]+)"', line)
        if not m:
            continue
        slug = m.group(1)
        name = None
        m2 = re.search(r'"children":"' + _ANY_STR + r'"', line)
        if m2:
            name = _unescape_json_str(m2.group(1))
        count_m = re.search(r'"children":(\d+)', line)
        count = count_m.group(1) if count_m else 0
        out.append({
            "slug": slug,
            "name": name or slug,
            "channel_count": int(count) if str(count).isdigit() else 0,
        })
    return out


# ---------------------------------------------------------------------------
# channel detail / embed pages
# ---------------------------------------------------------------------------

def parse_embed_streams(html_or_rsc):
    """Extract the full stream URL list from an /embed/<id> page.

    Returns dict: {"channel_id": "...", "channel_name": "...",
    "stream_urls": [...]}
    """
    text = _to_rsc(html_or_rsc)
    m = re.search(
        r'"channelId":"([^"]+)","channelName":"' + _ANY_STR +
        r'","streamUrls":(\[.*?\])', text, re.S)
    if not m:
        return None
    cid = m.group(1)
    cname = _unescape_json_str(m.group(2))
    urls = []
    try:
        urls = json.loads(m.group(3))
    except ValueError:
        urls = _all(re.compile(r'"((?:[^"\\]|\\.)*?)"'), m.group(3))
    return {"channel_id": cid, "channel_name": cname, "stream_urls": urls}


def parse_channel_detail(html_or_rsc):
    """Parse a /channel/<id> page.

    Uses the embedded JSON-LD (schema.org) data plus the card fields.

    Returns dict with keys: id, name, logo, description, country_name,
    language, stream_urls, programs (EPG now/next).
    """
    text = _to_rsc(html_or_rsc)
    result = {"id": None, "name": None, "logo": None, "description": None,
              "country_name": None, "language": None, "stream_urls": [],
              "programs": []}
    ld = _extract_jsonld(text)
    if ld:
        _apply_jsonld(result, ld)
    # player props (streamUrls) - fallback to embed-style parsing
    m = re.search(r'"streamUrls":(\[.*?\])', text, re.S)
    if m:
        try:
            result["stream_urls"] = json.loads(m.group(1))
        except ValueError:
            pass
    if not result["name"]:
        m = re.search(r'"children":"' + _ANY_STR + r'"', text)
        if m:
            result["name"] = _unescape_json_str(m.group(1))
    return result


def _extract_jsonld(text):
    """Return the schema.org JSON-LD dict that describes the channel.

    Channel pages embed two JSON-LD blocks: a site-wide WebSite block and a
    BroadcastService block. Prefer the one mentioning BroadcastService.
    """
    best = None
    for m in re.finditer(r'"__html":"(' + _ANY_STR + r')"', text, re.S):
        raw = m.group(1)
        try:
            # the __html value is itself a JSON string with escaped quotes
            ld = json.loads(json.loads('"' + raw + '"'))
        except (ValueError, UnicodeDecodeError):
            try:
                ld = json.loads(raw)
            except (ValueError, UnicodeDecodeError):
                continue
        if not isinstance(ld, dict):
            continue
        s = json.dumps(ld)
        if "BroadcastService" in s:
            return ld
        if best is None:
            best = ld
    return best


def _normalize_channel_id(value):
    """Strip a URL/#fragment JSON-LD @id down to the bare channel id."""
    if not value:
        return None
    m = re.search(r'/channel/([^#/]+)', value)
    if m:
        return m.group(1)
    if value.startswith("http"):
        return value.rstrip("#").rsplit("/", 1)[-1]
    return value


def _apply_jsonld(result, ld):
    graph = ld.get("@graph") or ([ld] if isinstance(ld, dict) else [])
    service = None
    events = []
    for node in graph:
        if not isinstance(node, dict):
            continue
        if node.get("@type") == "BroadcastService":
            service = node
        elif node.get("@type") == "BroadcastEvent":
            events.append(node)
    if service:
        result["id"] = _normalize_channel_id(service.get("@id")) or result["id"]
        result["name"] = service.get("name", result["name"])
        result["logo"] = service.get("image", result["logo"])
        result["country_name"] = service.get("areaServed", result["country_name"])
        lang = service.get("inLanguage")
        result["language"] = lang if lang else result["language"]
    for ev in events:
        result["programs"].append({
            "title": ev.get("name"),
            "start": ev.get("startDate"),
            "end": ev.get("endDate"),
            "live": bool(ev.get("isLiveBroadcast")),
        })
    result["programs"] = [p for p in result["programs"] if p.get("start")]


# ---------------------------------------------------------------------------
# guide (EPG) page
# ---------------------------------------------------------------------------

# program entries come in two forms:
#   keyed:   ["$","$L91","<iso>-<n>",{... "data-ga-id":"<id>","title":"..."}]
#   plain:   {.. "data-ga-id":"<id>","title":"...","className":"absolute
#             inset-y-1 ...","children":[["$","span",...],["$","span",...,
#             {"children":["09:20 AM"," \u2013 ","09:40 AM"]}]]}
_RE_GUIDE_PROGRAM = re.compile(
    r'\[\"\$\",\"\$L91\",\"([0-9TZ:.\-]+)-(\d+)\",\{[^}]*?'
    r'data-ga-id":"([^"]+)",[^}]*?"title":"' + _ANY_STR + r'"')

_EN_DASH = "\u2013"
_RE_GUIDE_TIME_ARRAY = re.compile(
    r'"children":\["([0-9]{1,2}:[0-9]{2}\s*[APap]\.?[Mm]\.?)","\s*' + _EN_DASH + r'\s*","'
    r'([0-9]{1,2}:[0-9]{2}\s*[APap]\.?[Mm]\.?)"\]')

_RE_GUIDE_GA_ID = re.compile(r'"data-ga-id":"([^"]+)"')
_RE_GUIDE_TITLE = re.compile(r'"title":"' + _ANY_STR + r'"')


def _utc_today_iso():
    import time
    t = time.gmtime()
    return "%04d-%02d-%02d" % (t.tm_year, t.tm_mon, t.tm_mday)


def _ampm_to_iso(ampm, day):
    """'09:20 AM' on <day> -> '2026-08-09T09:20:00.000Z' (guide renders UTC)."""
    m = re.match(r"(\d{1,2}):(\d{2})\s*([APap])", ampm or "")
    if not m:
        return None
    hour = int(m.group(1))
    minute = int(m.group(2))
    if m.group(3).lower() == "p" and hour < 12:
        hour += 12
    if m.group(3).lower() == "a" and hour == 12:
        hour = 0
    return "%sT%02d:%02d:00.000Z" % (day, hour, minute)


def parse_guide(html_or_rsc):
    """Parse the /guide page into channels and now/next programs.

    Returns dict: {"channels": [...], "programs": [...],
    "generated_at": iso or None}
    """
    text = _to_rsc(html_or_rsc)
    lines = rsc.split_lines(text)
    channels = {}
    row_re = re.compile(r'\[\"\$\",\"div\",\"([^\"]+)\",\{[^}]*?'
                        r'flex border-b border-border/40')
    for line in lines:
        for m in row_re.finditer(line):
            seg = line[m.start():]
            cid = m.group(1)
            m2 = re.search(r'"children":"' + _ANY_STR + r'"', seg)
            name = _unescape_json_str(m2.group(1)) if m2 else None
            logo = _first(re.compile(r'"src":"' + _ANY_STR + r'"'), seg)
            stream = _first(_RE_STREAM, seg)
            if stream == "$undefined":
                stream = None
            channels[cid] = {
                "id": cid,
                "name": name or cid,
                "logo": logo,
                "stream_url": stream,
            }
    programs = []
    seen = set()
    for m in _RE_GUIDE_PROGRAM.finditer(text):
        key = (m.group(3), m.group(1), m.group(2))
        if key in seen:
            continue
        seen.add(key)
        programs.append({
            "channel_id": m.group(3),
            "title": _unescape_json_str(m.group(4)),
            "start": m.group(1),
            "seq": int(m.group(2)),
        })
    today = _utc_today_iso()
    for m in _RE_GUIDE_TIME_ARRAY.finditer(text):
        before = text[max(0, m.start() - 3000):m.start()]
        ids = list(_RE_GUIDE_GA_ID.finditer(before))
        if not ids:
            continue
        id_m = ids[-1]
        cid = id_m.group(1)
        seg = text[id_m.end():m.start()]
        t = _RE_GUIDE_TITLE.search(seg)
        if not t:
            continue
        title = _unescape_json_str(t.group(1))
        start = _ampm_to_iso(m.group(1), today)
        if not start:
            continue
        key = (cid, start, title)
        if key in seen:
            continue
        seen.add(key)
        programs.append({
            "channel_id": cid,
            "title": title,
            "start": start,
            "seq": 0,
        })
    # derive end time from the next program on the same channel
    by_channel = {}
    for p in programs:
        by_channel.setdefault(p["channel_id"], []).append(p)
    for cid, items in by_channel.items():
        items.sort(key=lambda p: (p["start"] or "", p["seq"]))
        for i, p in enumerate(items):
            nxt = items[i + 1] if i + 1 < len(items) else None
            p["end"] = nxt["start"] if nxt else None
            p.pop("seq", None)
    return {
        "channels": list(channels.values()),
        "programs": programs,
        "generated_at": None,
    }


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _to_rsc(html_or_rsc):
    if rsc.has_rsc(html_or_rsc):
        return rsc.join_chunks(html_or_rsc)
    return html_or_rsc
