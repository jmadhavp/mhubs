# -*- coding: utf-8 -*-
"""Metadata helpers shared between the UI and the catalog.

Pure Python, no Kodi imports. Kodi-specific ListItem wiring lives in
resources/lib/kodi_ui.py.
"""

from __future__ import absolute_import, unicode_literals

import time

from . import epg as _epg


def subtitle(channel):
    """Build a one-line description for a channel."""
    parts = []
    country = channel.get("country_name")
    cats = [c.get("name") for c in (channel.get("categories") or []) if c.get("name")]
    if country:
        parts.append(country)
    if cats:
        parts.append(", ".join(cats[:3]))
    if channel.get("description"):
        parts.insert(0, channel["description"])
    return " | ".join(parts) if parts else ""


def searchable(channel):
    """Combine all searchable text fields into one lowercase blob."""
    fields = [
        channel.get("name"),
        channel.get("description"),
        channel.get("country_name"),
        channel.get("country_code"),
        channel.get("id"),
    ]
    for c in channel.get("categories") or []:
        fields.append(c.get("name"))
        fields.append(c.get("slug"))
    return " ".join([f for f in fields if f]).lower()


def match_query(channel, query_tokens):
    """Return True if every query token matches the channel's searchable text."""
    haystack = searchable(channel)
    return all(tok in haystack for tok in query_tokens)


def now_text(program):
    """Human-friendly 'now' label from a Program object, if present."""
    if not program or not program.title:
        return None
    return program.title


def format_time_iso(iso):
    """Format an ISO timestamp as local 'HH:MM' using the device clock."""
    ts = _iso_to_epoch(iso)
    if ts is None:
        return ""
    lt = time.localtime(ts)
    return "%02d:%02d" % (lt.tm_hour, lt.tm_min)


def _iso_to_epoch(iso):
    try:
        import epg as _epg
    except ImportError:  # pragma: no cover
        _epg = None
    if _epg is not None:
        return _epg.parse_iso(iso)
    return None
