# -*- coding: utf-8 -*-
"""Persistent user data: favorites, recently played, and local search.

Stores small JSON documents in the addon data directory. Favorites and
recently played only keep the identifiers needed to reconstruct a channel
plus a tiny display payload (name/logo).

No Kodi imports — the directory is passed in by the Kodi glue.
"""

from __future__ import absolute_import, unicode_literals

import json
import os
import time

from . import compat
from . import metadata

MAX_RECENT = 50


class Catalog(object):
    def __init__(self, directory):
        self.directory = directory
        try:
            if not os.path.isdir(directory):
                os.makedirs(directory)
        except (OSError, IOError):
            pass
        self._fav_path = os.path.join(directory, "favorites.json")
        self._recent_path = os.path.join(directory, "recent.json")

    # -- favorites ---------------------------------------------------------

    def get_favorites(self):
        return self._read(self._fav_path)

    def is_favorite(self, channel_id):
        return any(f.get("id") == channel_id for f in self.get_favorites())

    def add_favorite(self, channel):
        favs = self.get_favorites()
        for f in favs:
            if f.get("id") == channel.get("id"):
                return False
        favs.append(self._channel_stub(channel))
        self._write(self._fav_path, favs)
        return True

    def remove_favorite(self, channel_id):
        favs = [f for f in self.get_favorites() if f.get("id") != channel_id]
        self._write(self._fav_path, favs)

    # -- recently played ---------------------------------------------------

    def add_recent(self, channel):
        recents = self.get_recent()
        recents = [r for r in recents if r.get("id") != channel.get("id")]
        stub = self._channel_stub(channel)
        stub["played_at"] = time.time()
        recents.insert(0, stub)
        self._write(self._recent_path, recents[:MAX_RECENT])

    def get_recent(self):
        return self._read(self._recent_path)

    # -- local search ------------------------------------------------------

    def search(self, listings, query, limit=100):
        """Search over cached channel listings. Pure substring match."""
        tokens = [t for t in query.lower().split() if t]
        if not tokens:
            return []
        seen = set()
        out = []
        for ch in listings:
            cid = ch.get("id")
            if cid in seen:
                continue
            if metadata.match_query(ch, tokens):
                seen.add(cid)
                out.append(ch)
                if limit and len(out) >= limit:
                    break
        return out

    # -- storage helpers ---------------------------------------------------

    @staticmethod
    def _channel_stub(channel):
        return {
            "id": channel.get("id"),
            "name": channel.get("name"),
            "logo": channel.get("logo"),
            "stream_url": channel.get("stream_url"),
            "country_code": channel.get("country_code"),
            "country_name": channel.get("country_name"),
            "categories": (channel.get("categories") or [])[:4],
            "description": channel.get("description"),
        }

    @staticmethod
    def _read(path):
        try:
            with open(path, "rb") as fh:
                data = json.loads(fh.read().decode("utf-8"))
            return data if isinstance(data, list) else []
        except (OSError, IOError, ValueError, TypeError):
            return []

    @staticmethod
    def _write(path, value):
        tmp = path + ".tmp"
        try:
            with open(tmp, "wb") as fh:
                fh.write(json.dumps(value).encode("utf-8"))
            compat.replace_file(tmp, path)
        except (OSError, IOError):
            pass
