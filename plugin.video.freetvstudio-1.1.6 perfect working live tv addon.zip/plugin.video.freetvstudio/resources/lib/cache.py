# -*- coding: utf-8 -*-
"""Persistent JSON cache for the addon.

Stores small JSON documents in the addon data directory with per-namespace
time-to-live. Kept deliberately simple and dependency-free.

No Kodi imports — ``Cache`` takes its storage directory as an argument so it
can be unit tested on desktop Python. The Kodi glue passes the addon profile
directory.
"""

from __future__ import absolute_import, unicode_literals

import errno
import json
import os
import tempfile
import threading
import time

from . import compat

try:
    _LOCK = threading.RLock()
except Exception:  # pragma: no cover - exotic platforms
    _LOCK = None


class Cache(object):
    def __init__(self, directory, namespace="freetv"):
        self.directory = directory
        self.namespace = namespace
        try:
            if not os.path.isdir(directory):
                os.makedirs(directory)
        except (OSError, IOError) as e:
            if e.errno != errno.EEXIST:
                raise

    def _path(self, key):
        safe = "".join(c if c.isalnum() or c in "-_." else "_" for c in key)
        return os.path.join(self.directory, "%s_%s.json" % (self.namespace, safe))

    def get(self, key, default=None):
        """Return cached value if present and fresh, else default."""
        path = self._path(key)
        try:
            with open(path, "rb") as fh:
                data = json.loads(fh.read().decode("utf-8"))
            if data.get("expires", 0) < time.time():
                return default
            return data.get("value", default)
        except (OSError, IOError, ValueError, TypeError):
            return default

    def get_raw(self, key):
        """Return (value, expires_at) without checking freshness."""
        path = self._path(key)
        try:
            with open(path, "rb") as fh:
                data = json.loads(fh.read().decode("utf-8"))
            return data.get("value"), data.get("expires", 0)
        except (OSError, IOError, ValueError, TypeError):
            return None, 0

    def set(self, key, value, ttl_seconds):
        path = self._path(key)
        payload = {
            "value": value,
            "expires": time.time() + ttl_seconds,
        }
        tmp = path + ".tmp"
        with open(tmp, "wb") as fh:
            fh.write(json.dumps(payload).encode("utf-8"))
        try:
            compat.replace_file(tmp, path)
        except (OSError, IOError):
            # On some platforms replace is unavailable for existing files;
            # fall back to remove + rename.
            try:
                os.remove(path)
            except (OSError, IOError):
                pass
            try:
                os.rename(tmp, path)
            except (OSError, IOError):
                pass

    def delete(self, key):
        try:
            os.remove(self._path(key))
        except (OSError, IOError):
            pass

    def exists(self, key):
        return os.path.exists(self._path(key))

    def clear(self):
        """Remove every cache file for this namespace."""
        for name in os.listdir(self.directory):
            if name.startswith(self.namespace + "_") and name.endswith(".json"):
                try:
                    os.remove(os.path.join(self.directory, name))
                except (OSError, IOError):
                    pass

    def list_keys(self):
        keys = []
        for name in os.listdir(self.directory):
            if name.startswith(self.namespace + "_") and name.endswith(".json"):
                keys.append(name[len(self.namespace) + 1:-5])
        return keys


def default_cache_dir():
    """Used by tests/tools when no Kodi profile is available."""
    return os.path.join(tempfile.gettempdir(), "freetv_cache_test")
