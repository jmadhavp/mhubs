# -*- coding: utf-8 -*-
"""Kodi UI helpers: ListItem construction, directory building, playback.

Only this module (plus addon.py / router.py) touches Kodi APIs, so the logic
layers stay desktop-testable.
"""

from __future__ import absolute_import, unicode_literals

from . import compat
from . import kodi


def build_url(params):
    """Build a plugin:// URL for the given param dict."""
    base = "plugin://plugin.video.freetvstudio/"
    return base + "?" + compat.urlencode(params)


def make_listitem(channel, playable=True, fanart=None):
    """Create a Kodi ListItem for a channel dict."""
    item = kodi.xbmcgui.ListItem(label=channel.get("name") or channel.get("id"))
    logo = channel.get("logo") or ""
    art = {"thumb": logo, "icon": logo}
    if fanart:
        art["fanart"] = fanart
    if any(k for k in art):
        item.setArt({k: v for k, v in art.items() if v})

    info = {"title": channel.get("name") or channel.get("id"),
            "mediatype": "video"}
    desc = channel.get("description")
    if desc:
        info["plot"] = desc
    genres = [c.get("name") for c in (channel.get("categories") or []) if c.get("name")]
    if genres:
        info["genre"] = " / ".join(genres[:5])
    if channel.get("country_name"):
        info["country"] = channel["country_name"]
    item.setInfo("video", info)

    if playable and channel.get("stream_url"):
        item.setProperty("IsPlayable", "true")
    return item


def make_program_item(channel, program, prefix=""):
    """Build a ListItem that plays a channel, labelled with program info."""
    title = program.title if program else None
    label = title or channel.get("name") or channel.get("id")
    if prefix:
        label = "%s %s" % (prefix, label)
    item = make_listitem(channel, playable=True)
    item.setLabel(label)
    return item


def add_directory_items(handle, items):
    """Add (url, listitem, is_folder) triples to the directory."""
    kodi.xbmcplugin.addDirectoryItems(handle, items, len(items))


def end_directory(handle, succeeded=True, cache=True, content="videos"):
    if content:
        kodi.xbmcplugin.setContent(handle, content)
    kodi.xbmcplugin.endOfDirectory(handle, succeeded=succeeded,
                                   cacheToDisc=cache)


def set_resolved(handle, succeeded, item):
    kodi.xbmcplugin.setResolvedUrl(handle, succeeded, item)


def notify(title, message):
    try:
        kodi.xbmc.executebuiltin(
            "Notification(%s,%s)" % (title, message.replace(",", " ")))
    except Exception:  # noqa: BLE001
        pass


def get_setting(addon, key, default=""):
    try:
        val = addon.getSettingString(key)
        return val
    except Exception:  # noqa: BLE001
        try:
            return str(addon.getSetting(key))
        except Exception:  # noqa: BLE001
            return default
