import sys
import urllib

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcplugin
    _addon = xbmcaddon.Addon()
    _in_kodi = True
except ImportError:
    _addon = None
    _in_kodi = False

PLUGIN_BASE = 'plugin://plugin.video.hdmovie2/'


def log(msg, level=None):
    if not _in_kodi:
        print('[HDMovie2] {0}'.format(msg))
        return
    try:
        if level is None:
            level = xbmc.LOGDEBUG
        xbmc.log('[HDMovie2] {0}'.format(msg), level)
    except Exception:
        pass


def log_debug(msg):
    try:
        if _addon and _addon.getSetting('debug_log') == 'true':
            log(msg, xbmc.LOGDEBUG)
    except Exception:
        pass


def log_error(msg):
    log(msg, xbmc.LOGERROR)


def get_setting(name):
    if not _addon:
        return ''
    try:
        return _addon.getSetting(name)
    except Exception:
        return ''


def is_true(name):
    return get_setting(name).lower() == 'true'


def notify(title, message, error=False):
    if not _in_kodi:
        return
    try:
        icon = 'error' if error else 'info'
        xbmcgui.Dialog().notification(title, message, icon, 5000)
    except Exception:
        pass


def build_url(action, **kwargs):
    params = {'action': action}
    params.update(kwargs)
    query = urllib.urlencode([(k, v.encode('utf-8') if isinstance(v, unicode) else v)
                              for k, v in params.items()])
    return '{0}?{1}'.format(PLUGIN_BASE, query)


def add_dir(handle, url, label, thumb='', is_folder=True, info=None, playable=False, context=None):
    li = xbmcgui.ListItem(label)
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb})
    if info:
        li.setInfo('video', info)
    if playable:
        li.setProperty('IsPlayable', 'true')
    if context:
        li.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(handle, url, li, isFolder=is_folder)


def end_of_directory(handle, content=None, category=None):
    if content:
        xbmcplugin.setContent(handle, content)
    if category:
        xbmcplugin.setPluginCategory(handle, category)
    xbmcplugin.endOfDirectory(handle)


def pick_source(choices):
    if not choices:
        return None
    if len(choices) == 1:
        return choices[0][1]
    labels = [c[0] for c in choices]
    idx = xbmcgui.Dialog().select('Select source', labels)
    if idx < 0:
        return None
    return choices[idx][1]
