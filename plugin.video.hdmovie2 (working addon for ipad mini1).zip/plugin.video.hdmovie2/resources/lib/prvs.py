import hashlib
import json

try:
    import urllib2
except ImportError:
    pass

from resources.lib import client
from resources.lib.aes import aes256_ctr_decrypt
from resources.lib.kutils import log_debug, log_error

PLAYER_ORIGIN = 'https://prvs.top'


def decrypt_media(media_str, user_id, slug, md5_id):
    key_material = '{0}:{1}:{2}'.format(user_id, slug, md5_id)
    hex_digest = hashlib.md5(key_material.encode('utf-8')).hexdigest()
    key32 = hex_digest.encode('ascii')
    counter16 = key32[:16]
    data = media_str.encode('latin1')
    plain = aes256_ctr_decrypt(key32, counter16, data)
    return json.loads(plain.decode('utf-8', 'replace'))


def resolve(player_url, movie_page=None, screen='375x667'):
    """Fetch and decrypt the prvs.top stream config.

    Returns a dict with 'title', 'slug', 'sources' (list of candidate MP4
    urls), and 'raw' (decrypted config) or raises IOError with a message.
    """
    slug = None
    try:
        from urlparse import parse_qs, urlparse
    except ImportError:
        from urllib.parse import parse_qs, urlparse
    try:
        qs = parse_qs(urlparse(player_url).query)
        slug = (qs.get('v') or [''])[0]
    except Exception:
        pass
    if not slug:
        raise IOError('Could not extract slug from {0}'.format(player_url))

    info_url = PLAYER_ORIGIN + '/info/' + slug
    headers = {
        'x-client-screen': screen,
        'x-referer': movie_page or player_url,
    }
    data = client.fetch_json(info_url, headers=headers, referer=player_url)
    media = data.get('media')
    if not media:
        raise IOError('prvs.top returned no media payload')

    config = decrypt_media(media, data['user_id'], slug, data['md5_id'])
    log_debug('prvs.top decrypted config keys: {0}'.format(list(config.keys())))

    mp4 = config.get('mp4') or {}
    raw_sources = mp4.get('sources') or []
    sources = []
    for s in raw_sources:
        url = (s or {}).get('url')
        path = (s or {}).get('path')
        if url and path:
            sources.append({
                'label': s.get('label') or 'auto',
                'url': url.rstrip('/') + '/' + path.lstrip('/'),
                'size': s.get('size') or 0,
                'codec': s.get('codec') or '',
            })
    return {
        'title': data.get('title') or '',
        'slug': slug,
        'sources': sources,
        'raw': config,
    }
