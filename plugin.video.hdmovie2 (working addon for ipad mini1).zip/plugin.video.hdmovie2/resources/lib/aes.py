"""Minimal pure-Python AES-256 used to decrypt the prvs.top player config.

The player encrypts its stream metadata with WebCrypto AES-CTR using a
256-bit key that is the ASCII hex encoding of MD5("user_id:slug:md5_id")
and a 16-byte initial counter equal to the first 16 bytes of that key.

Only the forward cipher is needed here because a CTR keystream is produced
by AES-encrypting counter blocks (standard FIPS-197, column-major state).
"""

_SBOX = None
_RCON = None


def _rotl(b, n):
    return ((b << n) | (b >> (8 - n))) & 0xFF


def _gen_tables():
    global _SBOX, _RCON
    if _SBOX is not None:
        return
    sbox = [0] * 256
    p = q = 1
    while True:
        p = p ^ ((p << 1) & 0xFF) ^ (0x1B if p & 0x80 else 0)
        q ^= q << 1
        q ^= q << 2
        q ^= q << 4
        q ^= 0x09 if q & 0x80 else 0
        q &= 0xFF
        xformed = q ^ _rotl(q, 1) ^ _rotl(q, 2) ^ _rotl(q, 3) ^ _rotl(q, 4)
        sbox[p] = (xformed ^ 0x63) & 0xFF
        if p == 1:
            break
    sbox[0] = 0x63
    _SBOX = sbox
    _RCON = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80,
             0x1B, 0x36, 0x6C, 0xD8, 0xAB, 0x4D]


def _xtime(a):
    a <<= 1
    if a & 0x100:
        a ^= 0x11B
    return a & 0xFF


def _gmul(a, b):
    r = 0
    for _ in range(8):
        if b & 1:
            r ^= a
        a = _xtime(a)
        b >>= 1
    return r


def _key_expansion(key):
    _gen_tables()
    key = bytearray(key)
    nk = len(key) // 4
    nr = nk + 6
    words = [list(key[i * 4:(i + 1) * 4]) for i in range(nk)]
    rcon_idx = 0
    for i in range(nk, 4 * (nr + 1)):
        temp = list(words[i - 1])
        if i % nk == 0:
            temp = temp[1:] + temp[:1]
            temp = [_SBOX[b] for b in temp]
            temp[0] ^= _RCON[rcon_idx]
            rcon_idx += 1
        elif nk > 6 and i % nk == 4:
            temp = [_SBOX[b] for b in temp]
        words.append([words[i - nk][j] ^ temp[j] for j in range(4)])
    return [[b for word in words[r * 4:(r + 1) * 4] for b in word]
            for r in range(nr + 1)]


def _shift_rows(s):
    out = list(s)
    for r in (1, 2, 3):
        row = [s[r], s[r + 4], s[r + 8], s[r + 12]]
        shifted = row[r:] + row[:r]
        out[r] = shifted[0]
        out[r + 4] = shifted[1]
        out[r + 8] = shifted[2]
        out[r + 12] = shifted[3]
    return out


def _mix_columns(s):
    out = list(s)
    for c in range(4):
        v0, v1, v2, v3 = s[4 * c], s[4 * c + 1], s[4 * c + 2], s[4 * c + 3]
        out[4 * c] = _gmul(v0, 2) ^ _gmul(v1, 3) ^ v2 ^ v3
        out[4 * c + 1] = v0 ^ _gmul(v1, 2) ^ _gmul(v2, 3) ^ v3
        out[4 * c + 2] = v0 ^ v1 ^ _gmul(v2, 2) ^ _gmul(v3, 3)
        out[4 * c + 3] = _gmul(v0, 3) ^ v1 ^ v2 ^ _gmul(v3, 2)
    return out


def _add_round_key(state, rk):
    return [state[i] ^ rk[i] for i in range(16)]


def _encrypt_block(block, round_keys):
    _gen_tables()
    nr = len(round_keys) - 1
    state = _add_round_key(list(block), round_keys[0])
    for rnd in range(1, nr):
        state = [_SBOX[b] for b in state]
        state = _shift_rows(state)
        state = _mix_columns(state)
        state = _add_round_key(state, round_keys[rnd])
    state = [_SBOX[b] for b in state]
    state = _shift_rows(state)
    state = _add_round_key(state, round_keys[nr])
    return bytearray(state)


def _keystream(key, counter, length):
    round_keys = _key_expansion(list(key))
    ctr = bytearray(counter[:16])
    out = bytearray()
    while len(out) < length:
        out += _encrypt_block(ctr, round_keys)
        for i in range(15, -1, -1):
            ctr[i] = (ctr[i] + 1) & 0xFF
            if ctr[i]:
                break
    return bytes(out[:length])


def aes256_ctr_decrypt(key32, counter16, data):
    """Decrypt bytes using AES-256-CTR. key32 must be exactly 32 bytes and
    counter16 exactly 16 bytes. Counter increments as a big-endian 128-bit
    integer, matching WebCrypto AES-CTR with counter length 128."""
    if len(key32) != 32:
        raise ValueError('AES-256 key must be 32 bytes')
    if len(counter16) != 16:
        raise ValueError('CTR counter must be 16 bytes')
    ks = _keystream(key32, counter16, len(data))
    da = bytearray(data)
    ka = bytearray(ks)
    out = bytearray(len(data))
    for i in range(len(da)):
        out[i] = da[i] ^ ka[i]
    return bytes(out)
