"""Local HLS relay for Kodi 18 on iOS.

Kodi's HTTP client cannot send the Origin/Referer/User-Agent headers that
hdm2.ink requires for its playlists, and the signed JWT tokens expire while
a movie plays. This relay:

  * fetches master and variant playlists from hdm2.ink with the required
    headers,
  * rewrites every URI to point back at this local server so Kodi never
    talks to the CDN directly,
  * streams segments through without buffering (low RAM), and
  * re-resolves the stream chain when tokens expire (403 / Access Denied),
    so long movies keep playing.

Python 2.7 compatible (Kodi 18).
"""

import re
import socket
import threading
import time

try:
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from SocketServer import ThreadingMixIn
    _PY3 = False
except ImportError:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
    _PY3 = True

try:
    from urllib import unquote
except ImportError:
    from urllib.parse import unquote

try:
    from urlparse import urljoin
except ImportError:
    from urllib.parse import urljoin

from resources.lib import client
from resources.lib.kutils import log_debug, log_error

VARIANT_TTL = 420          # refresh variant playlist after 7 min (tokens last ~13)
MASTER_TTL = 2 * 3600      # re-resolve play page after 2 h (master token lasts 3 h)
CHUNK = 65536

_DEFAULT_INF = '#EXT-X-STREAM-INF:BANDWIDTH=1'


class Stream(object):
    def __init__(self, sid, spec):
        self.sid = sid
        self.spec = spec
        self.lock = threading.Lock()
        self.master_items = []     # list of {'url', 'inf'}
        self.master_ts = 0
        self.variants = {}         # n -> {'items': [...], 'ts': ts}

    def _playlist_headers(self):
        return client.build_headers(
            referer=self.spec.get('referer'),
            origin=self.spec.get('origin'),
        )

    def _fetch_master(self):
        url = self.spec.get('master_url')
        if not url:
            raise IOError('no master url in spec')
        text = client.fetch(url, headers=self._playlist_headers(), timeout=30)
        items = []
        pending_inf = _DEFAULT_INF
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            if line.startswith('#'):
                if line.startswith('#EXT-X-STREAM-INF'):
                    pending_inf = line
                continue
            if line.startswith('http') or line.startswith('/'):
                items.append({'url': urljoin(url, line), 'inf': pending_inf})
                pending_inf = _DEFAULT_INF
        if not items:
            raise IOError('master playlist has no variants (token may have expired)')
        with self.lock:
            self.master_items = items
            self.master_ts = time.time()
        return items

    def _refresh_master(self):
        """Master URL tokens expire; re-resolve the play page for fresh ones."""
        resolver = self.spec.get('resolver')
        if not resolver:
            raise IOError('no resolver available to refresh stream')
        spec = resolver()
        if spec.get('sid'):
            spec['sid'] = self.sid
        spec['resolver'] = resolver
        with self.lock:
            self.spec = spec
            self.master_items = []
            self.variants = {}
        return self._fetch_master()

    def _ensure_master(self):
        if not self.master_items or (time.time() - self.master_ts) >= MASTER_TTL:
            try:
                self._fetch_master()
            except IOError:
                self._refresh_master()
        if not self.master_items:
            raise IOError('master playlist unavailable')

    def _variant_items(self, n, force=False):
        with self.lock:
            cached = self.variants.get(n)
            cached_items = cached['items'] if cached else None
            ts = cached['ts'] if cached else 0
        if cached_items and not force and (time.time() - ts) < VARIANT_TTL:
            return cached_items
        self._ensure_master()
        if n >= len(self.master_items):
            raise IOError('variant index {0} out of range'.format(n))
        url = self.master_items[n]['url']
        text = client.fetch(url, headers=self._playlist_headers(), timeout=30)
        items = []
        pending_tag = None
        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            if line.startswith('#'):
                pending_tag = line
                continue
            if line.startswith('http') or line.startswith('/'):
                items.append({'url': urljoin(url, line), 'tag': pending_tag})
                pending_tag = None
        if not items:
            raise IOError('variant playlist {0} has no segments'.format(n))
        with self.lock:
            self.variants[n] = {'items': items, 'ts': time.time()}
        return items

    def _segment_url(self, n, i):
        n = int(n)
        items = self._variant_items(n)
        try:
            return items[int(i)]['url']
        except (ValueError, IndexError):
            raise IOError('bad segment index {0}/{1}'.format(n, i))

    def get_master_playlist(self, base):
        self._ensure_master()
        lines = ['#EXTM3U', '#EXT-X-VERSION:3']
        for i, item in enumerate(self.master_items):
            lines.append(item.get('inf') or _DEFAULT_INF)
            lines.append('{0}/v/{1}/{2}'.format(base, self.sid, i))
        return '\n'.join(lines) + '\n'

    def get_variant_playlist(self, n, base):
        try:
            items = self._variant_items(n)
        except IOError:
            self._refresh_master()
            items = self._variant_items(n)
        lines = ['#EXTM3U', '#EXT-X-VERSION:3']
        for i, item in enumerate(items):
            if item.get('tag'):
                lines.append(item['tag'])
            lines.append('{0}/s/{1}/{2}/{3}'.format(base, self.sid, n, i))
        return '\n'.join(lines) + '\n'


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.0'

    def log_message(self, fmt, *args):
        log_debug('relay: ' + fmt % args)

    def _send_error_text(self, code, msg):
        try:
            self.send_response(code)
            self.send_header('Content-Type', 'text/plain; charset=utf-8')
            body = msg.encode('utf-8') if _PY3 else msg
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            if self.command != 'HEAD':
                self.wfile.write(body)
        except Exception:
            pass

    def _stream(self, resp):
        try:
            headers = getattr(resp, 'headers', None)
            self.send_response(getattr(resp, 'code', 200))
            if headers:
                for hname in ('Content-Type', 'Content-Length',
                              'Content-Range', 'Accept-Ranges', 'Cache-Control'):
                    val = headers.get(hname)
                    if val:
                        self.send_header(hname, val)
            self.send_header('Connection', 'close')
            self.end_headers()
            if self.command == 'HEAD':
                return
            while True:
                chunk = resp.read(CHUNK)
                if not chunk:
                    break
                self.wfile.write(chunk)
        except (socket.error, IOError):
            pass
        finally:
            try:
                resp.close()
            except Exception:
                pass

    def _current_stream(self):
        sid = getattr(self.server, 'current_sid', None)
        if not sid or sid not in self.server.streams:
            raise IOError('unknown stream')
        return self.server.streams[sid]

    def _handle(self, head):
        try:
            path = unquote(self.path)
            if path.startswith('/m/'):
                self._serve_playlist(path)
            elif path.startswith('/v/'):
                self._serve_variant(path)
            elif path.startswith('/s/'):
                self._serve_segment(path)
            elif path.startswith('/f/'):
                self._serve_file(path)
            elif path.startswith('/stop'):
                threading.Thread(target=self.server.shutdown).start()
                self._send_error_text(200, 'stopping')
            else:
                self._send_error_text(404, 'not found')
        except IOError as e:
            log_error('relay error: {0}'.format(e))
            try:
                self._send_error_text(502, str(e))
            except Exception:
                pass
        except Exception as e:
            log_error('relay error: {0}'.format(e))
            try:
                self._send_error_text(500, str(e))
            except Exception:
                pass

    def _base_url(self):
        return 'http://{0}:{1}'.format(self.server.server_address[0],
                                       self.server.server_address[1])

    def _serve_playlist(self, path):
        stream = self._current_stream()
        body = stream.get_master_playlist(self._base_url())
        self._send_playlist(body)

    def _serve_variant(self, path):
        parts = path.split('/')
        if len(parts) < 4:
            raise IOError('bad variant path')
        try:
            n = int(parts[3])
        except ValueError:
            raise IOError('bad variant index')
        stream = self._current_stream()
        body = stream.get_variant_playlist(n, self._base_url())
        self._send_playlist(body)

    def _send_playlist(self, body):
        data = body.encode('utf-8') if _PY3 else body
        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Connection', 'close')
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(data)

    def _open_upstream(self, url, seg=False):
        if seg:
            headers = {'User-Agent': client.UA}
        else:
            stream = self._current_stream()
            headers = client.build_headers(referer=stream.spec.get('referer'),
                                           origin=stream.spec.get('origin'))
        return client.open_stream(url, headers=headers, timeout=60)

    def _serve_file(self, path):
        """Generic proxy for direct files (prvs.top MP4 fallback), adding the
        Referer/Origin headers Kodi cannot send, with Range passthrough."""
        import base64
        parts = path.split('/')
        if len(parts) < 3 or not parts[2]:
            raise IOError('bad file path')
        b64 = parts[2]
        try:
            raw = base64.b64decode(b64)
            url = raw.decode('utf-8') if isinstance(raw, bytes) else raw
        except Exception:
            raise IOError('bad file url')
        stream = self._current_stream()
        extra = {}
        rng = self.headers.get('Range')
        if rng:
            extra['Range'] = rng
        headers = client.build_headers(
            referer=stream.spec.get('referer'),
            origin=stream.spec.get('origin'),
            extra=extra)
        resp = client.open_stream(url, headers=headers, timeout=120)
        self._stream(resp)

    def _serve_segment(self, path):
        parts = path.split('/')
        if len(parts) < 5:
            raise IOError('bad segment path')
        n, i = parts[3], parts[4]
        stream = self._current_stream()
        url = stream._segment_url(n, i)
        # Tokens expire mid-movie: on 403 refresh the chain and retry once.
        for attempt in (0, 1):
            try:
                resp = self._open_upstream(url, seg=True)
                self._stream(resp)
                return
            except Exception as e:
                code = getattr(e, 'code', None)
                if attempt == 0 and code in (401, 403, 404):
                    log_debug('segment {0}/{1} failed ({2}); refreshing'.format(n, i, code))
                    stream._variant_items(int(n), force=True)
                    url = stream._segment_url(n, i)
                    continue
                raise

    def do_GET(self):
        self._handle(False)

    def do_HEAD(self):
        self._handle(True)


class RelayServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, server_address, handler):
        HTTPServer.__init__(self, server_address, handler)
        self.streams = {}
        self.current_sid = None


class Relay(object):
    def __init__(self, spec):
        self.spec = spec
        self.sid = spec.get('sid') or ('s' + str(int(time.time() * 1000))[-8:])
        self.server = None
        self.thread = None
        self.start()

    def start(self):
        self.server = RelayServer(('127.0.0.1', 0), Handler)
        self.port = self.server.server_address[1]
        self.server.streams[self.sid] = Stream(self.sid, self.spec)
        self.server.current_sid = self.sid
        self.thread = threading.Thread(target=self.server.serve_forever)
        self.thread.daemon = True
        self.thread.start()
        log_debug('relay started on port {0} sid {1}'.format(self.port, self.sid))

    @property
    def master_url(self):
        return 'http://127.0.0.1:{0}/m/{1}'.format(self.port, self.sid)

    def stop(self):
        try:
            if self.server:
                self.server.shutdown()
                self.server.server_close()
        except Exception:
            pass
        self.server = None
