import re

try:
    from urlparse import urljoin
except ImportError:
    from urllib.parse import urljoin

try:
    from urllib import urlencode
except ImportError:
    from urllib.parse import urlencode

from resources.lib import client
from resources.lib.kutils import log_debug, log_error

BROWSE_BASE = 'https://hdmovie2a.icu'

_article_re = re.compile(
    r'<article class="card">.*?'
    r'<img[^>]*src="([^"]+)"[^>]*alt="([^"]*)"[^>]*>.*?'
    r'<a class="poster-link"[^>]*href="([^"]+)"',
    re.DOTALL)
_source_re = re.compile(
    r'<a[^>]*data-source="([^"]+)"[^>]*>.*?'
    r'<span class="title">([^<]+)</span>',
    re.DOTALL)
_next_re = re.compile(r'<a class="next page-numbers"[^>]*href="([^"]+)"')
_genre_re = re.compile(
    r'<li><a href="(https://hdmovie2a\.icu/genre/[^"]+/)"[^>]*>([^<]+)</a>')

_quality_re = re.compile(r'<span class="quality">([^<]+)</span>')
_cover_re = re.compile(r'<img class="cover"[^>]*src="([^"]+)"')
_runtime_re = re.compile(r'<span class="runtime">([^<]+)</span>')
_date_re = re.compile(r'<span class="date">([^<]+)</span>')
_country_re = re.compile(r'<span class="country">([^<]+)</span>')
_h1_re = re.compile(r'<h1>([^<]+)</h1>')
_wpcontent_re = re.compile(r'<div class="wp-content">(.*?)</div>\s*</section>', re.DOTALL)


def _get(url, referer=None):
    return client.fetch(url, referer=referer or BROWSE_BASE + '/')


def parse_movies(html):
    movies = []
    for m in _article_re.finditer(html):
        thumb, alt, href = m.group(1), client.clean(m.group(2)), m.group(3)
        if not href:
            continue
        title = client.clean(alt) or href.rstrip('/').split('/')[-1]
        movies.append({'url': href, 'title': title, 'thumb': thumb})
    return movies


def parse_next_page(html, current_url):
    m = _next_re.search(html)
    if not m:
        return None
    return urljoin(current_url, m.group(1))


def parse_genres(html):
    genres = []
    seen = set()
    for m in _genre_re.finditer(html):
        url, name = m.group(1), client.clean(m.group(2))
        if name and url not in seen:
            seen.add(url)
            genres.append((name, url))
    return genres


def parse_detail(html):
    detail = {}
    m = _h1_re.search(html)
    if m:
        detail['title'] = client.clean(m.group(1))
    m = _cover_re.search(html)
    if m:
        detail['poster'] = m.group(1)
    m = _quality_re.search(html)
    if m:
        detail['quality'] = client.clean(m.group(1))
    for key, rx in (('runtime', _runtime_re), ('released', _date_re),
                    ('country', _country_re)):
        m = rx.search(html)
        if m:
            detail[key] = client.clean(m.group(1))
    m = _wpcontent_re.search(html)
    if m:
        text = re.sub(r'<script.*?</script>', '', m.group(1), flags=re.DOTALL)
        text = re.sub(r'<[^>]+>', ' ', text)
        detail['plot'] = client.clean(text)
    m = re.search(r'<meta property="og:description" content="([^"]+)"', html)
    if m and not detail.get('plot'):
        detail['plot'] = client.clean(m.group(1))
    return detail


def parse_sources(html):
    sources = []
    seen = set()
    for m in _source_re.finditer(html):
        url = client.unescape(m.group(1)).replace('&amp;', '&')
        name = client.clean(m.group(2))
        if url and url not in seen:
            seen.add(url)
            sources.append({'name': name or 'Stream', 'url': url})
    if not sources:
        for m in re.finditer(r'data-source="([^"]+)"', html):
            url = client.unescape(m.group(1)).replace('&amp;', '&')
            if url and url not in seen:
                seen.add(url)
                sources.append({'name': 'Stream', 'url': url})
    return sources


def get_index():
    html = _get(BROWSE_BASE + '/')
    return parse_movies(html), parse_genres(html), parse_next_page(html, BROWSE_BASE + '/')


def get_latest(page=1):
    url = BROWSE_BASE + '/page/{0}/'.format(page) if page > 1 else BROWSE_BASE + '/'
    html = _get(url)
    return parse_movies(html), parse_next_page(html, url)


def get_genre(genre_url, page=1):
    url = genre_url.rstrip('/') + '/page/{0}/'.format(page) if page > 1 else genre_url
    html = _get(url)
    return parse_movies(html), parse_next_page(html, url)


def search(query, page=1):
    qs = urlencode({'s': query.encode('utf-8')})
    url = BROWSE_BASE + '/?' + qs
    if page > 1:
        url = BROWSE_BASE + '/page/{0}/?{1}'.format(page, qs)
    html = _get(url)
    return parse_movies(html), parse_next_page(html, url)


def get_movie(url):
    html = _get(url, referer=BROWSE_BASE + '/')
    detail = parse_detail(html)
    detail['sources'] = parse_sources(html)
    return detail
