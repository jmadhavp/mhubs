import re
import socket
import ssl

try:
    import urllib2
    from urlparse import urljoin, urlparse, urlunparse, parse_qs
    import cookielib
    _PY3 = False
    _unichr = unichr
    _unicode = unicode
except ImportError:
    import urllib.request as urllib2
    from urllib.parse import urljoin, urlparse, urlunparse, parse_qs
    import http.cookiejar as cookielib
    _PY3 = True
    _unichr = chr
    _unicode = str

from resources.lib.kutils import log_error, log_debug

BASE = 'https://hdmovie2a.icu/'
ORIGIN = 'https://hdmovie2a.icu'
UA = ('Mozilla/5.0 (iPhone; CPU iPhone OS 16_5 like Mac OS X) '
      'AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 '
      'Mobile/15E148 Safari/604.1')

TIMEOUT = 30

_entity_re = re.compile(r'&(#?[xX]?[0-9a-fA-F]+|[a-zA-Z]+);')
_named = {
    'amp': '&', 'lt': '<', 'gt': '>', 'quot': '"', 'apos': "'",
    'nbsp': ' ', 'ndash': u'\u2013', 'mdash': u'\u2014', 'hellip': u'\u2026',
    'lsquo': u'\u2018', 'rsquo': u'\u2019', 'ldquo': u'\u201c', 'rdquo': u'\u201d',
    'times': u'\u00d7', 'middot': u'\u00b7', 'bull': u'\u2022',
    'copy': u'\u00a9', 'reg': u'\u00ae',
}

_cookie_jar = cookielib.CookieJar()
_opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(_cookie_jar))


def _entity_repl(m):
    ent = m.group(1)
    if ent.startswith('#x') or ent.startswith('#X'):
        return _unichr(int(ent[2:], 16))
    if ent.startswith('#'):
        return _unichr(int(ent[1:]))
    return _named.get(ent, m.group(0))


def unescape(text):
    if text is None:
        return u''
    if isinstance(text, str) and not _PY3:
        text = text.decode('utf-8', 'replace')
    return _entity_re.sub(_entity_repl, text)


def clean(text):
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def build_headers(extra=None, referer=None, origin=None):
    headers = {
        'User-Agent': UA,
        'Accept': ('text/html,application/xhtml+xml,application/xml;q=0.9,'
                   '*/*;q=0.8'),
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'identity',
        'Connection': 'keep-alive',
    }
    if referer:
        headers['Referer'] = referer
    if origin:
        headers['Origin'] = origin
    if extra:
        headers.update(extra)
    return headers


def _to_ascii(value):
    if not _PY3 and isinstance(value, _unicode):
        return value.encode('utf-8')
    return value


def _request(url, headers=None, timeout=None, method=None):
    if timeout is None:
        timeout = TIMEOUT
    req = urllib2.Request(_to_ascii(url), headers=headers or {})
    if method and hasattr(req, 'get_method'):
        req.get_method = lambda: method
    return req


def fetch(url, headers=None, referer=None, origin=None, timeout=None,
          binary=False, retries=2):
    """Fetch a URL and return its body.

    Returns str (text) or str/bytes (binary). Raises IOError on network
    failure. Detects the hdm2.ink 'Access Denied' Cloudflare block page and
    raises a descriptive exception.
    """
    hdrs = build_headers(headers, referer=referer, origin=origin)
    last_err = None
    for attempt in range(retries + 1):
        try:
            resp = _opener.open(_request(url, hdrs, timeout), timeout=timeout)
            body = resp.read()
            try:
                resp.close()
            except Exception:
                pass
            if not binary:
                if _PY3 and isinstance(body, bytes):
                    body = body.decode('utf-8', 'replace')
                elif not _PY3 and isinstance(body, str):
                    body = body.decode('utf-8', 'replace')
            _check_blocked(body)
            return body
        except urllib2.HTTPError as e:
            last_err = e
            log_debug('HTTP error {0} fetching {1}: {2}'.format(e.code, url, e.msg))
            if e.code in (401, 403, 404, 429) and attempt < retries:
                import time
                time.sleep(1.0 * (attempt + 1))
                continue
            raise
        except (urllib2.URLError, socket.error, ssl.SSLError,
                IOError, ValueError) as e:
            last_err = e
            log_debug('Network error fetching {0}: {1}'.format(url, e))
            if attempt < retries:
                import time
                time.sleep(1.0 * (attempt + 1))
                continue
            raise
    raise last_err


def _check_blocked(body):
    if not body:
        return
    text = body
    if isinstance(text, bytes):
        text = text.decode('utf-8', 'replace')
    if '<title>Access Denied</title>' in text or (
            '<h1>Access Denied.</h1>' in text):
        raise IOError('Cloudflare block: the request was denied. '
                      'Retry may help, or the source requires different headers.')


def open_stream(url, headers=None, referer=None, origin=None, timeout=60):
    """Open a URL and return a file-like response for streaming.

    Used by the relay so playlists/segments are streamed without buffering
    the whole body in memory (important on low-RAM devices).
    """
    hdrs = build_headers(headers, referer=referer, origin=origin)
    return _opener.open(_request(url, hdrs, timeout), timeout=timeout)


def fetch_json(url, headers=None, referer=None, origin=None, timeout=None,
               retries=2):
    import json
    body = fetch(url, headers=headers, referer=referer, origin=origin,
                 timeout=timeout, retries=retries, binary=True)
    if isinstance(body, str) and not _PY3:
        body = body
    if isinstance(body, bytes):
        body = body.decode('utf-8', 'replace')
    return json.loads(body)


def url_has_host(url, host):
    try:
        return urlparse(url).netloc.lower() == host.lower()
    except Exception:
        return False
