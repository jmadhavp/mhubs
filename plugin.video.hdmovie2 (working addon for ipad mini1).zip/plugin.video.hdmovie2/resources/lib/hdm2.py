import re

try:
    from urlparse import urljoin
except ImportError:
    from urllib.parse import urljoin

from resources.lib import client
from resources.lib.kutils import log_debug

PLAYER_ORIGIN = 'https://hdm2.ink'
SITE_ORIGIN = 'https://hdmovie2a.icu'

_stream_url_re = re.compile(r'data-stream-url\s*=\s*"([^"]+)"')


def resolve_play(play_url, movie_page=None):
    """Fetch the hdm2.ink play page and extract the signed master playlist URL.

    Returns a spec dict:
      master_url  - absolute URL of the master playlist (needs headers)
      play_url    - the play page (used as Referer for playlist requests)
      origin      - Origin header required for playlist requests
      referer     - Referer header required for playlist requests
      site_origin - Origin used to fetch the play page itself
      site_referer- Referer used to fetch the play page itself
    """
    if movie_page:
        page_headers = {
            'Origin': SITE_ORIGIN,
            'Referer': movie_page,
        }
    else:
        page_headers = {'Origin': SITE_ORIGIN}
    html = client.fetch(play_url, headers=page_headers)
    if 'Access Denied' in html:
        raise IOError('hdm2.ink blocked the request (Access Denied)')
    m = _stream_url_re.search(html)
    if not m:
        raise IOError('Could not find data-stream-url in play page')
    stream_path = client.unescape(m.group(1)).replace('&amp;', '&')
    master_url = urljoin(play_url, stream_path)
    log_debug('hdm2.ink master url: {0}'.format(master_url))
    return {
        'master_url': master_url,
        'play_url': play_url,
        'origin': PLAYER_ORIGIN,
        'referer': play_url,
        'site_origin': SITE_ORIGIN,
        'site_referer': movie_page or SITE_ORIGIN + '/',
    }


def is_hdm2(player_url):
    return 'hdm2.ink' in player_url
