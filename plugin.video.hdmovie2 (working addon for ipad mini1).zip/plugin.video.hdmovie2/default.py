import base64
import re
import sys
import threading
import time
import urllib

try:
    from urlparse import parse_qs, urlparse
    _PY3 = False
except ImportError:
    from urllib.parse import parse_qs, urlparse
    _PY3 = True

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib import client, scraper, hdm2, prvs
from resources.lib import relay as relay_mod

_addon = xbmcaddon.Addon()
_handle = int(sys.argv[1])
_url = sys.argv[0]

MAX_QUALITY = {'1': 720, '2': 480, '3': 360}

_relays = []


def _enc(value):
    if not _PY3 and isinstance(value, unicode):
        return value.encode('utf-8')
    return value


def get_setting(name):
    return _addon.getSetting(name)


def is_true(name):
    return get_setting(name).lower() == 'true'


def build_url(action, **kwargs):
    kwargs['action'] = action
    return '{0}?{1}'.format(_url, urllib.urlencode(
        [(k, _enc(v)) for k, v in kwargs.items()]))


def add_dir(name, url, thumb='', is_folder=True, info=None, playable=False, context=None):
    li = xbmcgui.ListItem(name)
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb})
    if info:
        li.setInfo('video', info)
    if playable:
        li.setProperty('IsPlayable', 'true')
    if context:
        li.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=is_folder)


def end(category=None, content=None):
    if content:
        xbmcplugin.setContent(_handle, content)
    if category:
        xbmcplugin.setPluginCategory(_handle, category)
    xbmcplugin.endOfDirectory(_handle)


def index():
    try:
        movies, genres, nxt = scraper.get_index()
    except Exception as e:
        notify_error('Could not load site: {0}'.format(e))
        return
    add_dir('Search', build_url('search'), '', False)
    add_dir('Latest Movies', build_url('latest', page=1))
    add_dir('Genres', build_url('genres'))
    for m in movies:
        url = build_url('movies', url=m['url'], name=m['title'],
                        thumb=m['thumb'])
        info = {'title': m['title'], 'mediatype': 'video'}
        add_dir(m['title'], url, m['thumb'], True, info)
    if nxt:
        add_dir('Next Page >>', build_url('latest', page=2))
    end('HDMovie2', 'videos')


def latest():
    page = int(_params('page', '1'))
    url = build_url('latest', page=page + 1)
    try:
        movies, nxt = scraper.get_latest(page)
    except Exception as e:
        notify_error('Could not load page: {0}'.format(e))
        return
    for m in movies:
        add_dir(m['title'], build_url('movies', url=m['url'],
                                      name=m['title'], thumb=m['thumb']),
                m['thumb'], True, {'title': m['title'], 'mediatype': 'video'})
    if nxt:
        add_dir('Next Page >>', url)
    end('Latest Movies', 'videos')


def genres():
    try:
        html = client.fetch(scraper.BROWSE_BASE + '/')
        glist = scraper.parse_genres(html)
    except Exception as e:
        notify_error('Could not load genres: {0}'.format(e))
        return
    for name, gurl in glist:
        add_dir(name, build_url('genre', url=gurl, page=1))
    end('Genres')


def genre():
    gurl = _params('url', '')
    page = int(_params('page', '1'))
    if not gurl:
        return
    try:
        movies, nxt = scraper.get_genre(gurl, page)
    except Exception as e:
        notify_error('Could not load genre: {0}'.format(e))
        return
    for m in movies:
        add_dir(m['title'], build_url('movies', url=m['url'],
                                      name=m['title'], thumb=m['thumb']),
                m['thumb'], True, {'title': m['title'], 'mediatype': 'video'})
    if nxt:
        add_dir('Next Page >>', build_url('genre', url=gurl, page=page + 1))
    end('Genre', 'videos')


def search():
    kb = xbmcgui.Dialog().input('Search HDMovie2', type=xbmcgui.INPUT_ALPHANUM)
    if kb:
        xbmc.executebuiltin('Container.Update({0})'.format(
            build_url('search_results', q=kb)))
    end()


def search_results():
    q = _params('q', '')
    page = int(_params('page', '1'))
    if not q:
        return
    try:
        movies, nxt = scraper.search(q, page)
    except Exception as e:
        notify_error('Search failed: {0}'.format(e))
        return
    if not movies:
        add_dir('No results found', '', False)
    for m in movies:
        add_dir(m['title'], build_url('movies', url=m['url'],
                                      name=m['title'], thumb=m['thumb']),
                m['thumb'], True, {'title': m['title'], 'mediatype': 'video'})
    if nxt:
        add_dir('Next Page >>', build_url('search_results', q=q, page=page + 1))
    end('Search: {0}'.format(q), 'videos')


def movies():
    murl = _params('url', '')
    name = _params('name', '')
    thumb = _params('thumb', '')
    if not murl:
        return
    try:
        detail = scraper.get_movie(murl)
    except Exception as e:
        notify_error('Could not load movie: {0}'.format(e))
        return
    title = detail.get('title') or name
    info = {'title': title, 'plot': detail.get('plot', ''),
            'mediatype': 'video'}
    poster = detail.get('poster') or thumb
    sources = detail.get('sources') or []
    if not sources:
        notify_error('No video sources found for this title')
        return
    for s in sources:
        label = '{0}  [{1}]'.format(s['name'], s['url'].split('//')[-1].split('/')[0])
        play_url = build_url('play', url=s['url'], title=title,
                             page=murl, thumb=poster)
        add_dir(label, play_url, poster, False, info, True)
    end('{0}'.format(title), 'videos')


def play():
    player_url = _params('url', '')
    title = _params('title', '')
    movie_page = _params('page', '')
    if not player_url:
        return
    try:
        if hdm2.is_hdm2(player_url):
            final = _play_hdm2(player_url, movie_page, title)
        else:
            final = _play_prvs(player_url, movie_page, title)
    except Exception as e:
        notify_error('Playback failed: {0}'.format(e))
        return
    li = xbmcgui.ListItem(path=final, label=title)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(_handle, True, li)
    _start_monitor()


def _play_hdm2(player_url, movie_page, title):
    spec = hdm2.resolve_play(player_url, movie_page or None)
    movie_page_ref = movie_page

    def resolver():
        return hdm2.resolve_play(player_url, movie_page_ref or None)

    spec['resolver'] = resolver
    r = relay_mod.Relay(spec)
    _relays.append(r)
    return r.master_url


def _play_prvs(player_url, movie_page, title):
    data = prvs.resolve(player_url, movie_page)
    sources = data.get('sources') or []
    if not sources:
        raise Exception('prvs.top returned no playable sources')
    chosen = _choose_source(sources)
    spec = {
        'referer': 'https://prvs.top/?v=' + data.get('slug', ''),
        'origin': 'https://prvs.top',
    }
    r = relay_mod.Relay(spec)
    if _PY3:
        b64 = base64.b64encode(chosen.encode('utf-8')).decode('utf-8')
    else:
        b64 = base64.b64encode(_enc(chosen))
    final = 'http://127.0.0.1:{0}/f/{1}'.format(r.port, b64)
    _relays.append(r)
    return final


def _choose_source(sources):
    cap = MAX_QUALITY.get(get_setting('max_quality'))
    ordered = sorted(sources, key=lambda s: (s.get('size') or 0), reverse=True)
    for s in ordered:
        size = s.get('size') or 0
        height = _height_from_size(size)
        if cap and height and height > cap:
            continue
        return s['url']
    return ordered[0]['url']


def _height_from_size(size):
    if size > 900 * 1024 * 1024:
        return 720
    if size > 500 * 1024 * 1024:
        return 480
    return 360


def notify_error(msg):
    xbmcgui.Dialog().notification('HDMovie2', str(msg), xbmcgui.NOTIFICATION_ERROR)


def _stop_relays():
    for r in _relays:
        try:
            r.stop()
        except Exception:
            pass
    del _relays[:]


def _start_monitor():
    def _watch():
        started = False
        begin = time.time()
        try:
            while True:
                playing = xbmc.Player().isPlaying()
                if playing:
                    started = True
                elif started:
                    break
                elif time.time() - begin > 30:
                    break
                xbmc.sleep(2000)
        except Exception:
            pass
        _stop_relays()

    t = threading.Thread(target=_watch)
    t.daemon = True
    t.start()


def _params(name, default=''):
    try:
        vals = _query.get(name)
        if vals:
            return vals[0]
    except Exception:
        pass
    return default


_query = {}


def main():
    global _query
    try:
        _query = parse_qs(sys.argv[2].lstrip('?'))
    except Exception:
        _query = {}
    action = _params('action', 'index')
    handlers = {
        'index': index,
        'latest': latest,
        'genres': genres,
        'genre': genre,
        'search': search,
        'search_results': search_results,
        'movies': movies,
        'play': play,
    }
    handler = handlers.get(action, index)
    try:
        handler()
    except Exception as e:
        notify_error('Error: {0}'.format(e))
        end()


if __name__ == '__main__':
    main()
