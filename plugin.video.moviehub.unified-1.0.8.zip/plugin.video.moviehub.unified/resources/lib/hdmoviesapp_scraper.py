# -*- coding: utf-8 -*-
"""
HDMoviesApp Scraper - https://hdmoviesapp.com
Uses IndStream player (slast430did.com)
"""

import re
import urllib.request
import urllib.parse
import ssl
import base64

BASE = "https://hdmoviesapp.com"
PLAYER_BASE = "https://slast430did.com"

_ctx = ssl.create_default_context()
_ctx.check_hostname = False
_ctx.verify_mode = ssl.CERT_NONE


def _fetch(url, headers=None):
    hdrs = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    }
    if headers:
        hdrs.update(headers)
    req = urllib.request.Request(url, headers=hdrs)
    try:
        resp = urllib.request.urlopen(req, context=_ctx, timeout=20)
        return resp.read().decode("utf-8", errors="ignore")
    except Exception:
        return ""


def _abs(url, base=BASE):
    if url.startswith("//"):
        return "https:" + url
    if url.startswith("http"):
        return url
    return urllib.parse.urljoin(base, url)


def _extract_listing(html):
    """Extract movies from listing page"""
    items = []
    seen = set()

    for article in re.findall(r'<article[^>]*>(.*?)</article>', html, re.DOTALL):
        a = re.search(r'<a[^>]+href="([^"]+\.html)"[^>]*>', article)
        if not a:
            continue

        url = _abs(a.group(1))
        if url in seen:
            continue
        seen.add(url)

        title = ""
        tm = re.search(r'<h2[^>]*>(.*?)</h2>', article, re.DOTALL)
        if tm:
            title = _clean_text(tm.group(1))
        if not title:
            tm = re.search(r'title="([^"]+)"', article)
            if tm:
                title = tm.group(1)
        if not title:
            title = _slug_to_title(url)

        thumb = ""
        img_m = re.search(r'<img[^>]+src="([^"]+)"', article, re.I)
        if img_m:
            thumb = img_m.group(1)

        # Extract year from title or URL
        year = ""
        ym = re.search(r'\((\d{4})\)', title)
        if ym:
            year = ym.group(1)

        items.append({"title": title, "url": url, "thumb": thumb, "year": year})

    return items


def get_latest(page=1):
    """Get latest movies"""
    if page <= 1:
        url = BASE + "/"
    else:
        url = BASE + f"/page/{page}/"

    html = _fetch(url)
    if not html:
        return []

    return _extract_listing(html)


def get_genre(genre, page=1):
    """Get movies by genre"""
    if page <= 1:
        url = BASE + f"/{genre}"
    else:
        url = BASE + f"/{genre}/page/{page}/"

    html = _fetch(url)
    if not html:
        return []

    return _extract_listing(html)


def search(query, page=1):
    """Search movies"""
    q = urllib.parse.quote(query)
    url = BASE + f"/index.php?do=search&subaction=search&story={q}"
    if page > 1:
        url += f"&page={page}"

    html = _fetch(url)
    if not html:
        return []

    return _extract_listing(html)


def get_detail(url):
    """Get movie details and sources"""
    html = _fetch(url)
    if not html:
        return None

    title = ""
    tm = re.search(r'<h1[^>]*>(.*?)</h1>', html, re.DOTALL)
    if tm:
        title = _clean_text(tm.group(1))
    if not title:
        tm = re.search(r'property="og:title"[^>]*content="([^"]+)"', html)
        if tm:
            title = tm.group(1)

    poster = ""
    pm = re.search(r'property="og:image"[^>]*content="([^"]+)"', html)
    if not pm:
        pm = re.search(r'<img[^>]+class="[^"]*poster[^"]*"[^>]+src="([^"]+)"', html, re.I)
    if pm:
        poster = pm.group(1)

    plot = ""
    dm = re.search(r'<div[^>]*class="[^"]*(?:description|summary|plot)[^"]*"[^>]*>(.*?)</div>', html, re.DOTALL)
    if dm:
        plot = _clean_text(dm.group(1))

    sources = []

    # Extract IMDB ID for IndStream player
    imdb_id = ""
    imdb_m = re.search(r'data-imdb="([^"]+)"', html)
    if not imdb_m:
        imdb_m = re.search(r'IMDB:\s*<[^>]*>([^<]+)<', html, re.I)
    if imdb_m:
        imdb_id = imdb_m.group(1).strip()

    if imdb_id:
        # Return the IndStream player URL - resolver will handle it
        player_url = f"{PLAYER_BASE}/play/{imdb_id}"
        sources.append({
            "label": "IndStream (HD)",
            "url": player_url,
            "host": "indstream"
        })

    # Fallback: look for any iframe embeds
    if not sources:
        for ifr in re.findall(r'<iframe[^>]+src="([^"]+)"', html, re.I):
            ifr = _abs(ifr, url)
            if ifr.startswith("http"):
                host = urllib.parse.urlparse(ifr).netloc.replace("www.", "")
                sources.append({"label": f"Source ({host})", "url": ifr, "host": host})

    return {"title": title, "poster": poster, "plot": plot, "sources": sources}


def get_genres():
    return [
        ("Action", "action"),
        ("Adventure", "adventure"),
        ("Animation", "animation"),
        ("Bollywood", "bollywood"),
        ("Comedy", "comedy"),
        ("Crime", "crime"),
        ("Documentary", "documentary"),
        ("Drama", "drama"),
        ("Family", "family"),
        ("Fantasy", "fantasy"),
        ("Hollywood", "hollywood"),
        ("Horror", "horror"),
        ("Musical", "musical"),
        ("Mystery", "mystery"),
        ("Romance", "romance"),
        ("Sci-Fi", "sci-fi"),
        ("Thriller", "thriller"),
        ("Web Series", "web-series"),
    ]


def _slug_to_title(url):
    path = urllib.parse.urlparse(url).path
    seg = path.rstrip("/").split("/")[-1]
    seg = re.sub(r"\.html?$", "", seg)
    seg = re.sub(r"^\d+-", "", seg)
    seg = seg.replace("-", " ")
    return seg.title().strip()


def _clean_text(txt):
    txt = re.sub(r"<[^>]+>", "", txt)
    txt = re.sub(r"\s+", " ", txt).strip()
    return txt
