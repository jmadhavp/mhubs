# -*- coding: utf-8 -*-
"""StreamIMDB addon entry point.

Python 2.7 (Kodi 18 Leia) / Python 3 compatible. Mirrors the structure of the
user's existing working HDMovie2 addon: a flat default.py router plus a
resources/lib with pure-stdlib scraping/resolving.

IMPORTANT (Kodi 18 / Python 2.7): the addon identifies itself to Kodi as a
plugin, so it must contain only executable code at module scope (no syntax
that Python 2.7 can't parse). The heavy imports are wrapped so that ANY failure
shows a visible notification instead of a silent crash.
"""

import sys

try:
    from urlparse import parse_qs
    _PY3 = False
except ImportError:
    from urllib.parse import parse_qs
    _PY3 = True

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin


# ---------------------------------------------------------------------------
# Safe bootstrap. If anything here fails we surface it instead of dying silently.
# ---------------------------------------------------------------------------

def _fatal(msg):
    """Last-resort visible error before Kodi swallows the traceback."""
    try:
        xbmcgui.Dialog().notification(
            'StreamIMDB', str(msg), xbmcgui.NOTIFICATION_ERROR, 12000)
    except Exception:
        try:
            xbmc.log('[StreamIMDB] ' + str(msg), xbmc.LOGERROR)
        except Exception:
            pass
    try:
        xbmcplugin.endOfDirectory(1, False)
    except Exception:
        pass


def _boot():
    problems = []
    try:
        import resources.lib.scraper as scraper
    except Exception as e:
        problems.append('import scraper: %s' % e)
        scraper = None
    try:
        import resources.lib.resolver as resolver_mod
    except Exception as e:
        problems.append('import resolver: %s' % e)
        resolver_mod = None
    return scraper, resolver_mod, problems


try:
    _addon = xbmcaddon.Addon()
except Exception:
    _addon = None
try:
    _handle = int(sys.argv[1])
except Exception:
    _handle = 1
_url = sys.argv[0] if len(sys.argv) > 0 else 'plugin://plugin.video.streamimdb'

MAX_QUALITY = {'1': '720p', '2': '480p', '3': '360p'}


def get_setting(name, default=''):
    try:
        v = _addon.getSetting(name)
    except Exception:
        return default
    return v if v is not None else default


def is_true(name):
    return get_setting(name).lower() == 'true'


def _enc(value):
    if not _PY3 and isinstance(value, unicode):  # noqa: F821
        return value.encode('utf-8')
    return value


def build_url(action, **kwargs):
    kwargs['action'] = action
    return '{0}?{1}'.format(_url, _urlencode(
        [(k, _enc(v)) for k, v in kwargs.items()]))


def _urlencode(items):
    try:
        from urllib import urlencode
    except ImportError:
        from urllib.parse import urlencode
    return urlencode(items)


def add_dir(name, url, thumb='', is_folder=True, info=None, playable=False,
            context=None):
    li = xbmcgui.ListItem(name)
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb})
    if info:
        li.setInfo('video', info)
    if playable:
        li.setProperty('IsPlayable', 'true')
    if context:
        li.addContextMenuItems(context)
    xbmcplugin.addDirectoryItem(_handle, url, li, isFolder=is_folder)


def end(category=None, content=None):
    if content:
        xbmcplugin.setContent(_handle, content)
    if category:
        xbmcplugin.setPluginCategory(_handle, category)
    xbmcplugin.endOfDirectory(_handle)


def notify(msg, error=False):
    try:
        xbmcgui.Dialog().notification(
            'StreamIMDB', str(msg),
            xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO)
    except Exception:
        pass


def notify_error(msg):
    notify(msg, error=True)


def index(scraper):
    add_dir('Search', build_url('search'), is_folder=False)
    add_dir('Latest Movies', build_url('listing', url=scraper.BASE + 'movies'))
    add_dir('Latest TV Shows', build_url('listing', url=scraper.BASE + 'tv-shows'))
    add_dir('Categories', build_url('categories'))
    add_dir('Years', build_url('years'))
    end('StreamIMDB', 'videos')


def categories(scraper):
    try:
        cats = scraper.get_categories()
    except Exception as e:
        notify_error('Could not load categories: {0}'.format(e))
        return
    for name, url in cats:
        add_dir(name, build_url('listing', url=url), is_folder=True)
    end('Categories')


def years(scraper):
    try:
        yrs = scraper.get_years()
    except Exception as e:
        notify_error('Could not load years: {0}'.format(e))
        return
    for y, url in yrs:
        add_dir(y, build_url('listing', url=url), is_folder=True)
    end('Years')


def listing(scraper):
    url = _params('url', '')
    page = int(_params('page', '1'))
    if not url:
        return
    try:
        items, nxt = scraper.get_listing(url, page)
    except Exception as e:
        notify_error('Could not load page: {0}'.format(e))
        return
    if not items:
        add_dir('No results', '', is_folder=False)
    for it in items:
        info = {'title': it['title'], 'mediatype': 'video'}
        embed = it.get('embed', '')
        if it['kind'] == 'tv':
            add_dir(it['title'], build_url('detail', url=it['url'],
                                           title=it['title'], thumb=it['thumb']),
                    it['thumb'], True, info)
        else:
            add_dir(it['title'], build_url('detail', url=it['url'],
                                           title=it['title'], thumb=it['thumb'],
                                           embed=embed),
                    it['thumb'], True, info)
    if nxt:
        add_dir('Next Page >>', build_url('listing', url=nxt, page=page + 1))
    end('StreamIMDB', 'videos')


def detail(scraper, resolver_mod):
    durl = _params('url', '')
    if not durl:
        return
    try:
        d = scraper.get_detail(durl)
    except Exception as e:
        notify_error('Could not load title: {0}'.format(e))
        return
    title = d.get('title') or _params('title', 'Video')
    info = {'title': title, 'plot': d.get('plot', ''), 'mediatype': 'video'}
    poster = d.get('poster') or _params('thumb', '')
    embed = _params('embed', '') or d.get('embed')
    if d.get('episodes'):
        seasons = {}
        for ep in d['episodes']:
            seasons.setdefault(ep['season'], []).append(ep)
        for s in sorted(seasons):
            add_dir('Season %d' % s,
                    build_url('season', url=durl, season=s),
                    poster, True, info)
        end(title)
        return
    if not embed:
        notify_error('No player found for this title')
        return
    play_url = build_url('play', embed=embed, title=title, thumb=poster)
    add_dir('{0}  [Play]'.format(title), play_url, poster, False, info, True)
    end(title, 'videos')


def season(scraper):
    durl = _params('url', '')
    s = _params('season', '1')
    try:
        d = scraper.get_detail(durl)
    except Exception as e:
        notify_error('Could not load show: {0}'.format(e))
        return
    eps = [e for e in d.get('episodes', []) if str(e.get('season')) == str(s)]
    if not eps:
        notify_error('No episodes found for this season')
        return
    title = d.get('title') or _params('title', 'TV')
    poster = d.get('poster', '')
    for ep in sorted(eps, key=lambda x: x.get('episode', 0)):
        label = 'S{0}E{1} - {2}'.format(ep['season'], ep['episode'], ep['title'])
        info = {'title': label, 'mediatype': 'video',
                'season': ep['season'], 'episode': ep['episode']}
        add_dir(label, build_url('play', url=ep['url'], title=label,
                                 thumb=poster),
                poster, False, info, True)
    end(title)


def play(scraper, resolver_mod):
    embed = _params('embed', '')
    page_url = _params('url', '')
    title = _params('title', 'Video')
    thumb = _params('thumb', '')
    if not embed and not page_url:
        return
    if not embed and page_url:
        try:
            d = scraper.get_detail(page_url)
            embed = d.get('embed')
        except Exception as e:
            notify_error('Could not load player: {0}'.format(e))
            xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
            return
    if not embed:
        notify_error('No player found for this title')
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
        return
    preferred = MAX_QUALITY.get(get_setting('max_quality'), 'Auto')
    try:
        final = resolver_mod.resolve(embed, preferred=preferred)
    except IOError as e:
        if 'BLOCKED' in str(e):
            notify_error('Upstream player is blocked by Cloudflare. '
                         'Play this title in a real browser instead.')
        else:
            notify_error('Playback failed: {0}'.format(e))
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
        return
    except Exception as e:
        notify_error('Playback failed: {0}'.format(e))
        xbmcplugin.setResolvedUrl(_handle, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(path=final, label=title)
    li.setArt({'thumb': thumb, 'icon': thumb})
    li.setInfo('video', {'title': title, 'mediatype': 'video'})
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(_handle, True, li)


def search():
    kb = xbmcgui.Dialog().input('Search StreamIMDB',
                                type=xbmcgui.INPUT_ALPHANUM)
    if kb:
        xbmc.executebuiltin('Container.Update({0})'.format(
            build_url('search_results', q=kb)))
    end()


def search_results(scraper):
    q = _params('q', '')
    page = int(_params('page', '1'))
    if not q:
        return
    try:
        items, nxt = scraper.search(q, page)
    except Exception as e:
        notify_error('Search failed: {0}'.format(e))
        return
    if not items:
        add_dir('No results found', '', is_folder=False)
    for it in items:
        info = {'title': it['title'], 'mediatype': 'video'}
        add_dir(it['title'], build_url('detail', url=it['url'],
                                       title=it['title'], thumb=it['thumb']),
                it['thumb'], True, info)
    if nxt:
        add_dir('Next Page >>', build_url('search_results', q=q, page=page + 1))
    end('Search: {0}'.format(q), 'videos')


def _params(name, default=''):
    try:
        vals = _query.get(name)
        if vals:
            return vals[0]
    except Exception:
        pass
    return default


_query = {}


def main():
    global _query
    try:
        _query = parse_qs(sys.argv[2].lstrip('?'))
    except Exception:
        _query = {}

    scraper, resolver_mod, problems = _boot()
    if problems:
        _fatal('Load error: ' + ' | '.join(problems))
        return

    action = _params('action', 'index')
    handlers = {
        'index': lambda: index(scraper),
        'categories': lambda: categories(scraper),
        'years': lambda: years(scraper),
        'listing': lambda: listing(scraper),
        'detail': lambda: detail(scraper, resolver_mod),
        'season': lambda: season(scraper),
        'play': lambda: play(scraper, resolver_mod),
        'search': search,
        'search_results': lambda: search_results(scraper),
    }
    handler = handlers.get(action, lambda: index(scraper))
    try:
        handler()
    except Exception as e:
        notify_error('Error: {0}'.format(e))
        end()


if __name__ == '__main__':
    main()
