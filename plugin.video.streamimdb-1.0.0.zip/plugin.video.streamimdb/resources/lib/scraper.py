# -*- coding: utf-8 -*-
"""StreamIMDB scraper.

Parses the server-rendered HTML of https://streamimdb.ru . The site uses a
"Cineby / VidAPI" theme: listings link to /movie/<slug> and /tv/<slug>[/season/
<n>/episode/<n>]; the inline player loads an iframe from /embed/movie/<tmdbid>
or /embed/tv/<tmdbid>/<season>/<episode>.

All parsing is regex/DOM-free so it runs on Python 2.7 (Kodi 18 Leia).
"""

import re

try:
    from urllib import urlencode
    _PY2 = True
    unicode = unicode  # noqa: F821
except ImportError:
    from urllib.parse import urlencode
    _PY2 = False

from resources.lib import client

BASE = 'https://streamimdb.ru/'

# A listing card anchors look like:
#   <a href="/movie/85v64-spider-man-no-way-home" ...>
#   <a href="/tv/11mrm-lucky/season/1/episode/1" ...>
_RE_CARD = re.compile(
    r'<a\s+[^>]*href="(/movie/[^"]+|/tv/[^"]+)"[^>]*>(.*?)</a>',
    re.DOTALL | re.I)

# Thumbnails use TMDB image CDN.
_RE_IMG = re.compile(r'<img[^>]*src="([^"]+)"', re.I)

# Title appears in the card anchor text or in an <h3>/<span> inside it.
_RE_TITLE_TEXT = re.compile(r'alt="([^"]+)"', re.I)

# A listing "slide" exposes the real title + the embed id directly:
#   <button ... class="cb-slide-play" data-embed="/embed/movie/950028"
#           data-title="The Invite"> ... </button>
#   <img ... alt="The Invite" class="cb-slide-title-logo">
#   <div class="cb-slide-bg" style="background-image:url('...jpg')"></div>
_RE_SLIDE = re.compile(
    r'data-embed="(/embed/(?:movie|tv)/[^"]+)"\s+data-title="([^"]+)"',
    re.I)
_RE_SLIDE_BG = re.compile(
    r'cb-slide-bg"[^>]*style="[^"]*url\(\s*[\'"]?([^\'")]+)', re.I)
_RE_SLIDE_DETAIL = re.compile(
    r'<a\s+[^>]*href="(/movie/[^"]+|/tv/[^"]+)"[^>]*>\s*<i[^>]*>'
    r'</i>\s*Details', re.I)

_RE_NEXT = re.compile(r'href="([^"]+)"[^>]*>\s*(?:Next|&raquo;|&gt;)\s*<', re.I)

_RE_YEAR = re.compile(r'/year/(\d{4})')

_QUALITY_RE = re.compile(r'(?:(\d{3,4})[pP])')


def _clean_href(href):
    if href.startswith('//'):
        return 'https:' + href
    if href.startswith('http'):
        return href
    return BASE.rstrip('/') + href


def _extract_thumb(card_html):
    m = _RE_IMG.search(card_html)
    if m:
        return m.group(1)
    return ''


def _extract_title(card_html, href):
    # Prefer alt="..." on an image inside the card.
    m = _RE_TITLE_TEXT.search(card_html)
    if m:
        t = client.clean(m.group(1))
        if t:
            return t
    # Otherwise the last non-empty text chunk.
    txt = re.sub(r'<[^>]+>', ' ', card_html)
    txt = client.clean(txt)
    if txt:
        return txt
    return href.rstrip('/').split('/')[-1].split('-', 1)[-1]


def parse_cards(html):
    """Return list of {url, title, thumb, kind, embed} from a listing page.

    Slides are the authoritative source (real title + direct embed id). When a
    page has no slides (some category/year listings) we fall back to parsing the
    plain card anchors.
    """
    out = []
    seen = set()
    if html:
        for m in _RE_SLIDE.finditer(html):
            embed = _clean_href(m.group(1))
            title = client.clean(m.group(2))
            # Locate the slide block and pull detail link + poster.
            start = max(0, m.start() - 1600)
            block = html[start:m.end() + 400]
            dm = _RE_SLIDE_DETAIL.search(block)
            href = dm.group(1) if dm else None
            bgm = _RE_SLIDE_BG.search(block)
            thumb = bgm.group(1) if bgm else ''
            if not href:
                # derive from embed id
                em_id = embed.rstrip('/').split('/')[-1]
                kind = 'tv' if '/tv/' in embed else 'movie'
                href = '/%s/%s' % (kind, em_id)
            href = _clean_href(href)
            if href in seen:
                continue
            seen.add(href)
            kind = 'tv' if '/tv/' in href else 'movie'
            out.append({
                'url': href,
                'title': title or href.rstrip('/').split('/')[-1],
                'thumb': thumb,
                'kind': kind,
                'embed': embed,
            })
    if out:
        return out
    # Fallback: parse cb-card blocks (used by /movies, /category/*, etc.)
    for cm in re.finditer(r'<div class="cb-card"[^>]*>(.*?)</div>\s*</a>',
                          html or '', re.DOTALL):
        block = cm.group(1)
        lm = re.search(r'href="(/movie/[^"]+|/tv/[^"]+)"', block, re.I)
        if not lm:
            continue
        href = _clean_href(lm.group(1))
        if href in seen:
            continue
        seen.add(href)
        tm = re.search(r'cb-card-title"[^>]*title="([^"]+)"', block, re.I)
        if not tm:
            tm = re.search(r'alt="([^"]+)"', block, re.I)
        title = client.clean(tm.group(1)) if tm else href.rstrip('/').split('/')[-1]
        im = re.search(r'<img[^>]*src="([^"]+)"', block, re.I)
        thumb = im.group(1) if im else ''
        kind = 'tv' if '/tv/' in href else 'movie'
        out.append({
            'url': href,
            'title': title,
            'thumb': thumb,
            'kind': kind,
            'embed': '',
        })
    if out:
        return out
    # Last resort: plain anchors.
    for m in _RE_CARD.finditer(html or ''):
        href = m.group(1)
        card = m.group(2)
        if href in seen:
            continue
        seen.add(href)
        kind = 'tv' if '/tv/' in href else 'movie'
        out.append({
            'url': _clean_href(href),
            'title': _extract_title(card, href),
            'thumb': _extract_thumb(card),
            'kind': kind,
            'embed': '',
        })
    return out


def parse_next(html, current_url):
    m = _RE_NEXT.search(html or '')
    if m:
        return _clean_href(m.group(1))
    return None


def parse_categories(html):
    out = []
    seen = set()
    for m in re.finditer(r'href="(/category/[^"]+)"[^>]*>([^<]+)</a>', html or ''):
        href, name = m.group(1), client.clean(m.group(2))
        if href in seen:
            continue
        if not name:
            continue
        seen.add(href)
        out.append((name, _clean_href(href)))
    return out


def parse_years(html):
    out = []
    for y in sorted(set(_RE_YEAR.findall(html or ''))):
        out.append((y, _clean_href('/year/' + y)))
    return out


def parse_detail(html):
    """Extract metadata from a movie/tv detail page."""
    detail = {}
    m = re.search(r'<h1[^>]*>([^<]+)</h1>', html or '')
    if m:
        detail['title'] = client.clean(m.group(1))
    m = re.search(r'<meta property="og:title" content="([^"]+)"', html or '')
    if not detail.get('title') and m:
        detail['title'] = client.clean(m.group(1))
    m = re.search(r'<meta property="og:image" content="([^"]+)"', html or '')
    if m:
        detail['poster'] = m.group(1)
    m = re.search(r'<meta property="og:description" content="([^"]+)"',
                  html or '')
    if m:
        detail['plot'] = client.clean(m.group(1))
    # Inline player embed reference (data-src on the iframe).
    m = re.search(r'data-src="(/embed/[^"]+)"', html or '')
    if not m:
        m = re.search(r'href="(/embed/[^"]+)"', html or '')
    if m:
        detail['embed'] = _clean_href(m.group(1))
    # Episode list for TV shows.
    if '/tv/' in (html and 'tv' or '') or detail.get('embed', '').startswith(
            BASE + 'embed/tv'):
        eps = []
        for em in re.finditer(
                r'href="(/tv/[^"]+/season/(\d+)/episode/(\d+))"', html or ''):
            eps.append({
                'url': _clean_href(em.group(1)),
                'season': int(em.group(2)),
                'episode': int(em.group(3)),
                'title': _extract_title('', em.group(1)),
            })
        detail['episodes'] = eps
    return detail


def parse_seasons(html):
    """Return [(season_number, url)] for a TV show page."""
    out = []
    seen = set()
    for m in re.finditer(r'href="(/tv/[^"]+/season/(\d+))"', html or ''):
        s = int(m.group(2))
        if s in seen:
            continue
        seen.add(s)
        out.append((s, _clean_href(m.group(1))))
    return sorted(out)


def parse_episodes(html):
    """Return list of {url, season, episode, title} from a season page."""
    out = []
    seen = set()
    for m in re.finditer(
            r'href="(/tv/[^"]+/season/(\d+)/episode/(\d+))"', html or ''):
        url = _clean_href(m.group(1))
        if url in seen:
            continue
        seen.add(url)
        out.append({
            'url': url,
            'season': int(m.group(2)),
            'episode': int(m.group(3)),
            'title': _extract_title('', url),
        })
    return out


def get_home():
    return parse_cards(client.fetch(BASE))


def get_listing(url, page=1):
    target = url
    if page and page > 1:
        sep = '&' if '?' in target else '?'
        target = '%s%spage=%d' % (target, sep, page)
    html = client.fetch(target)
    return parse_cards(html), parse_next(html, target)


def get_detail(url):
    return parse_detail(client.fetch(url, referer=BASE))


def search(query, page=1):
    if _PY2 and isinstance(query, unicode):  # noqa: F821
        qval = query.encode('utf-8')
    elif not _PY2 and isinstance(query, bytes):
        qval = query.decode('utf-8')
    else:
        qval = query
    qs = urlencode({'q': qval})
    url = BASE + 'search?' + qs
    if page and page > 1:
        url += '&page=%d' % page
    html = client.fetch(url, referer=BASE)
    return parse_cards(html), parse_next(html, url)


def get_categories():
    return parse_categories(client.fetch(BASE))


def get_years():
    return parse_years(client.fetch(BASE))
