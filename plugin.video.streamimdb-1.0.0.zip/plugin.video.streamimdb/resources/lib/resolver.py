# -*- coding: utf-8 -*-
"""Stream resolver for StreamIMDB.

Given the site's embed URL (/embed/movie/<id> or /embed/tv/<id>/s/e) this tries
to return a directly playable stream URL (HLS .m3u8 or progressive .mp4).

Playback flow on StreamIMDB:
    detail page  -> iframe  /embed/<type>/<id>...
                 -> iframe  https://nextgencloudfabric.com/embed/<type>/<id>...
                 -> Cloudflare Turnstile challenge (anti-bot)

The Turnstile wall cannot be solved from inside Kodi, so when we hit it the
resolver raises a clear exception and the UI reports it. If the embed ever
exposes a direct .m3u8/.mp4 (some titles do), we return it.
"""

import re

from resources.lib import client

RE_M3U8 = re.compile(r'https?://[^\s"\'<>\\]+?\.m3u8(?:\?[^\s"\'<>]*)?', re.I)
RE_MP4 = re.compile(r'https?://[^\s"\'<>\\]+?\.mp4(?:\?[^\s"\'<>]*)?', re.I)
RE_SRC_VAR = re.compile(
    r'''(?:file|src|hls|url|source|video|stream|playlist|manifest)\s*[:=]\s*["\']([^"\']+\.(?:m3u8|mp4)[^"\']*)["\']''',
    re.I)
RE_JSON_SOURCES = re.compile(r'sources\s*:\s*(\[.*?\])', re.I | re.DOTALL)
RE_FILE_VAR = re.compile(r'["\']file["\']\s*:\s*["\']([^"\']+)["\']', re.I)
RE_IFRAME = re.compile(r'<iframe[^>]*src=["\']([^"\']+)["\']', re.I)

QUALITY_ORDER = ["1080", "720", "480", "360", "240", "144"]


def _host(url):
    try:
        from urlparse import urlparse
    except ImportError:
        from urllib.parse import urlparse
    return urlparse(url).netloc.lower().replace('www.', '')


def _abs(url, base):
    if url.startswith('//'):
        return 'https:' + url
    if url.startswith('http'):
        return url
    try:
        from urlparse import urljoin
    except ImportError:
        from urllib.parse import urljoin
    return urljoin(base, url)


def _quality_of(url):
    for q in QUALITY_ORDER:
        if re.search(r'[._-]?%s[pP]' % q, url):
            return int(q)
    return 0


def pick_quality(urls, preferred='Auto'):
    if not urls:
        return None
    if preferred and preferred != 'Auto':
        wanted = re.sub(r'[^0-9]', '', preferred)
        for u in urls:
            if wanted and re.search(r'[._-]?%s[pP]' % wanted, u):
                return u
    return sorted(urls, key=_quality_of, reverse=True)[0]


def _scan_html(html, base):
    found = []
    for m in RE_M3U8.findall(html or ''):
        found.append(_abs(m, base))
    for m in RE_MP4.findall(html or ''):
        found.append(_abs(m, base))
    for m in RE_SRC_VAR.findall(html or ''):
        found.append(_abs(m, base))
    for m in RE_FILE_VAR.findall(html or ''):
        u = m.replace('\\/', '/')
        if u.startswith('http'):
            found.append(u)
    for block in RE_JSON_SOURCES.findall(html or ''):
        for fm in re.findall(r'file\s*:\s*["\']([^"\']+)["\']', block):
            u = fm.replace('\\/', '/')
            if u.startswith('http'):
                found.append(u)
    seen, out = set(), []
    for u in found:
        if u not in seen:
            seen.add(u)
            out.append(u)
    return out


def resolve(embed_url, preferred='Auto'):
    """Return a playable stream URL or raise IOError with a clear reason."""
    # 1) fetch the site's embed page
    html = client.fetch(embed_url, referer=client.BASE)
    media = _scan_html(html, embed_url)
    if media:
        return pick_quality(media, preferred)
    # 2) follow the iframe one level (nextgencloudfabric etc.)
    iframes = RE_IFRAME.findall(html or '')
    for ifr in iframes[:3]:
        iu = _abs(ifr, embed_url)
        try:
            ih = client.fetch(iu, referer=embed_url)
        except IOError as e:
            if 'BLOCKED' in str(e):
                raise
            continue
        media = _scan_html(ih, iu)
        if media:
            return pick_quality(media, preferred)
    # 3) nothing usable -> either blocked or no direct source
    if 'turnstile' in (html or '').lower() or 'cf-chl' in (html or '').lower():
        raise IOError('BLOCKED: upstream player is behind a Cloudflare '
                      'challenge; open the title in a browser to play.')
    raise IOError('No direct stream found for this title. The source may '
                  'require a browser-only player.')
