# -*- coding: utf-8 -*-
"""Lightweight HTTP client for StreamIMDB.

Pure standard library, fully Python 2.7 (Kodi 18 Leia) / Python 3 compatible.
Mirrors the proven structure of the user's existing HDMovie2 addon so it runs
on an iPad mini 1 / iOS 9.3.5. Handles gzip, cookies, redirects and detects
Cloudflare / Turnstile anti-bot block pages.
"""

import re
import socket
import ssl
import time

try:
    import urllib2
    from urlparse import urljoin, urlparse, parse_qs
    import cookielib
    _PY3 = False
    _unicode = unicode  # noqa: F821
    _bytes = str
except ImportError:
    import urllib.request as urllib2
    from urllib.parse import urljoin, urlparse, parse_qs
    import http.cookiejar as cookielib
    _PY3 = True
    _unicode = str
    _bytes = bytes


BASE = 'https://streamimdb.ru/'
ORIGIN = 'https://streamimdb.ru'

UA = ('Mozilla/5.0 (iPhone; CPU iPhone OS 9_3_5 like Mac OS X) '
      'AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 '
      'Mobile/13G36 Safari/601.1')

TIMEOUT = 30

_entity_re = re.compile(r'&(#?[xX]?[0-9a-fA-F]+|[a-zA-Z]+);')
_named = {
    'amp': '&', 'lt': '<', 'gt': '>', 'quot': '"', 'apos': "'",
    'nbsp': ' ', 'ndash': u'\u2013', 'mdash': u'\u2014', 'hellip': u'\u2026',
    'lsquo': u'\u2018', 'rsquo': u'\u2019', 'ldquo': u'\u201c', 'rdquo': u'\u201d',
    'times': u'\u00d7', 'middot': u'\u00b7', 'bull': u'\u2022',
    'copy': u'\u00a9', 'reg': u'\u00ae',
}

_cookie_jar = cookielib.CookieJar()
_opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(_cookie_jar))

# Cloudflare / Turnstile challenge markers. When present the upstream player is
# protected by an anti-bot wall that cannot be solved from Kodi.
_BLOCK_MARKERS = (
    '<title>Access Denied</title>',
    '<h1>Access Denied.</h1>',
    'cf-turnstile',
    'challenges.cloudflare.com/turnstile',
    'verify you are human',
    'Just a moment',
)


def _entity_repl(m):
    ent = m.group(1)
    if ent.startswith('#x') or ent.startswith('#X'):
        return _unichr(int(ent[2:], 16))
    if ent.startswith('#'):
        return _unichr(int(ent[1:]))
    return _named.get(ent, m.group(0))


def _unichr(code):
    if _PY3:
        return chr(code)
    return unichr(code)  # noqa: F821


def unescape(text):
    if text is None:
        return u''
    if isinstance(text, bytes) and not _PY3:
        text = text.decode('utf-8', 'replace')
    return _entity_re.sub(_entity_repl, text)


def clean(text):
    text = unescape(text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def build_headers(extra=None, referer=None, origin=None):
    headers = {
        'User-Agent': UA,
        'Accept': ('text/html,application/xhtml+xml,application/xml;q=0.9,'
                   '*/*;q=0.8'),
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
    }
    if referer:
        headers['Referer'] = referer
    if origin:
        headers['Origin'] = origin
    if extra:
        headers.update(extra)
    return headers


def _to_ascii(value):
    if not _PY3 and isinstance(value, _unicode):
        return value.encode('utf-8')
    return value


def _request(url, headers=None, timeout=None):
    return urllib2.Request(_to_ascii(url), headers=headers or {})


def _decode(body, resp):
    enc = resp.headers.get('Content-Encoding', '')
    if enc == 'gzip':
        import gzip
        import io
        body = gzip.GzipFile(fileobj=io.BytesIO(body)).read()
    elif enc == 'deflate':
        import zlib
        body = zlib.decompress(body)
    return _to_text(body)


def _to_text(body):
    """Coerce bytes/unicode to a unicode text string on both Py2 and Py3."""
    if body is None:
        return u''
    if isinstance(body, bytes) and not _PY3:
        # Py2: urllib2 returns str (bytes)
        try:
            return body.decode('utf-8', 'replace')
        except Exception:
            return body
    if isinstance(body, bytes):
        return body.decode('utf-8', 'replace')
    return body


def _check_blocked(body):
    if not body:
        return
    text = _to_text(body)
    low = text.lower()
    for marker in _BLOCK_MARKERS:
        if marker.lower() in low:
            raise IOError(
                'BLOCKED: the upstream player is protected by a Cloudflare / '
                'Turnstile challenge that cannot be solved inside Kodi. '
                'Open the link in a real browser instead.')
    return text


def fetch(url, headers=None, referer=None, origin=None, timeout=None,
          retries=2):
    """Fetch a URL and return decoded text. Raises IOError on failure."""
    if timeout is None:
        timeout = TIMEOUT
    hdrs = build_headers(headers, referer=referer, origin=origin)
    last_err = None
    for attempt in range(retries + 1):
        try:
            resp = _opener.open(_request(url, hdrs, timeout), timeout=timeout)
            try:
                body = resp.read()
                text = _decode(body, resp)
            finally:
                try:
                    resp.close()
                except Exception:
                    pass
            return _check_blocked(text)
        except urllib2.HTTPError as e:
            last_err = e
            if e.code in (401, 403, 404, 429) and attempt < retries:
                time.sleep(1.0 * (attempt + 1))
                continue
            raise
        except (urllib2.URLError, socket.error, ssl.SSLError,
                IOError, ValueError) as e:
            last_err = e
            if attempt < retries:
                time.sleep(1.0 * (attempt + 1))
                continue
            raise
    raise last_err


def fetch_binary(url, headers=None, referer=None, origin=None, timeout=60):
    """Fetch raw bytes (used for probing/scanning embed pages)."""
    hdrs = build_headers(headers, referer=referer, origin=origin)
    resp = _opener.open(_request(url, hdrs, timeout), timeout=timeout)
    try:
        return resp.read()
    finally:
        try:
            resp.close()
        except Exception:
            pass


def open_stream(url, headers=None, referer=None, origin=None, timeout=60):
    """Open a URL and return a file-like response for direct streaming."""
    hdrs = build_headers(headers, referer=referer, origin=origin)
    return _opener.open(_request(url, hdrs, timeout), timeout=timeout)


def url_has_host(url, host):
    try:
        return urlparse(url).netloc.lower() == host.lower()
    except Exception:
        return False
